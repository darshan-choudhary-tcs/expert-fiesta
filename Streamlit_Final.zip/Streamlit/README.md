# GenAI Hackathon Boilerplate

Production-ready Streamlit platform for Retrieval-Augmented Generation (RAG), Multi-Agent reasoning (LangGraph), Explainability, Grounding, PII Scrubbing, and dual LLM provider support (OpenAI-compatible / Ollama).

For full deep-dive see: `docs/ARCHITECTURE.md`.

## Core Features (Condensed)

- Multi-Agent orchestration (LangGraph) for complex queries
- Robust RAG pipeline (chunking → embeddings → ChromaDB retrieval → answer synthesis)
- Explainability & grounding (sources, confidence, citations, agent traces)
- Provider switching: OpenAI-compatible or local Ollama (LLM + embeddings)
- Resilient embedding subsystem (batch + retry + per-item fallback)
- Secure auth (JWT + bcrypt) & session utilities
- PII scrubbing (scrubadub) prior to vectorization
- Admin UI for runtime configuration & performance tunables
- Corporate-themed Streamlit UI with dynamic layout widths

## Quick Start

```bash
cd "AI Friday/Streamlit"
pip install -r requirements.txt
cp .env.example .env
streamlit run main.py
```

Then visit the Admin page to choose provider (OpenAI or Ollama) and adjust embedding tunables.

## Structure (High-Level)

See `docs/ARCHITECTURE.md` for detailed map.

```
app/pages      # UI pages (dashboard, uploader, explainability, admin, auth)
core/llm       # LLM + embeddings + prompts
core/agents    # LangGraph agents, nodes, tools
services       # RAG, vector store, grounding, explainability, PII
models         # SQLite ORM models
utils          # Auth, session, logging, metrics, validators, ollama helper
config         # Settings & prompt registry
static         # CSS theme
docs           # Setup & architecture guides
```

## Usage (Abbreviated)

1. Register & login.
2. Upload documents (RAG Uploader) → auto chunk + embed.
3. Ask questions in Dashboard (choose RAG or Multi-Agent).
4. Toggle Insights for sources, confidence, agent trace.
5. Adjust provider + embedding settings in Admin.
6. Use PII Scrubber before ingesting sensitive text.

Ollama setup: install, pull `llama3.2` + `nomic-embed-text`, select provider in Admin. See `docs/OLLAMA_SETUP.md`.

## Extension Pointers

Add agent: implement in `core/agents/agent_nodes.py`, register in `agent_graph.py`.
Add tool: create `@tool` in `core/agents/agent_tools.py`.
New retrieval strategy: add method to `services/vector_store.py` then branch in `RAGService`.
Provider: extend `config/settings.py` + branch in `core/llm/llm_config.py` / `embeddings.py`.
Prompts: update `core/llm/prompts.py`.

## Architecture Snapshot
RAG: ingest → chunk → embed (retry-safe) → store (Chroma) → retrieve (similarity/MMR) → assemble context → generate → attribute sources.
Multi-Agent: graph routes query through specialized nodes → optional reflection → synthesis → trace captured.
Grounding: confidence + citations; explainability clamps unsafe values.

## Stack
Streamlit · LangChain/LangGraph · Ollama/OpenAI · ChromaDB · SQLite · JWT/bcrypt · scrubadub · PyPDF / python-docx.

## Performance Tips
Tune embedding batch size & retry delays (Admin). Reduce chunk size for high-recall, increase for cost efficiency. Monitor latency & tokens in metrics panel.

## Security Notes
Rotate `JWT_SECRET_KEY`, scrub PII before embedding, prefer local Ollama for sensitive data, add rate limiting & HTTPS in production. Roles (`admin`, `editor`, `user`) enforced via decorators (`require_admin`, `require_editor`). Admin panel enables role assignment.

## License
Hackathon boilerplate - customize freely.

## Support
See `docs/ARCHITECTURE.md` and inline module docstrings. Open issues for gaps.
