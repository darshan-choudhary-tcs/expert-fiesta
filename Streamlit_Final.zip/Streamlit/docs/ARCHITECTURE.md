# GenAI Platform Architecture

A production-oriented Streamlit application providing RAG (Retrieval-Augmented Generation), Multi-Agent reasoning, Explainability, Grounding, PII Scrubbing, and dynamic provider configuration (OpenAI / Ollama). This document explains every module, data flow, and extension pathway so new contributors can onboard quickly and safely evolve the system.

---
## 1. High-Level Overview

| Layer | Purpose | Key Directories |
|-------|---------|-----------------|
| UI / Presentation | User workflows, interaction, visualization | `app/pages`, `static/` |
| Orchestration | LLM provider abstraction, agent graph, prompts | `core/llm`, `core/agents`, `config/` |
| Services | Business logic (RAG, embeddings, document processing, explainability) | `services/` |
| Persistence | Relational + vector storage, metrics | `models/`, ChromaDB path, SQLite DB |
| Utilities | Cross-cutting concerns: auth, session, logging, validators, metrics | `utils/` |
| Configuration | Central settings, environment wiring | `config/settings.py`, `.env`, `.streamlit/config.toml` |
| Documentation | Setup guides & architecture references | `docs/` |

Primary design goals:
- Modularity: Each capability isolated in a dedicated service.
- Provider Flexibility: Seamless switch between remote (OpenAI-compatible) and local (Ollama).
- Observability: Token usage, latency, confidence scoring.
- Extensibility: Adding agents, retrieval strategies, document types, or providers is low-friction.
- Robustness: Embedding fallbacks, retries, safe UI clamping, singleton vector store client.

---
## 2. Runtime Data Flow

### 2.1 Document Ingestion
1. User uploads file via `rag_uploader.py`.
2. `DocumentProcessor.extract_text_*` handles PDF/DOCX/TXT.
3. Text cleaned and segmented with sentence-aware chunking (`chunk_text`).
4. Metadata per chunk (filename, chunk index, user, total count).
5. Embeddings generated (batch → fallback sequential if transient errors) via `embed_texts`.
6. Stored in ChromaDB collection; metadata & doc record saved in SQLite.

### 2.2 Retrieval-Augmented Generation (RAG)
1. User enters query in `dashboard.py` (RAG mode).
2. `RAGService.query()`:
   - Resets token counter.
   - Retrieves docs using similarity or MMR (`VectorStoreService`).
   - Formats context with prompt template.
   - Calls LLM (`ChatOllama` or `ChatOpenAI`).
   - Computes confidence metrics (relevance average).
   - Records metrics (latency, tokens, relevance) in DB.
3. UI shows answer, sources, optional explainability.

### 2.3 Multi-Agent Reasoning
1. User selects Multi-Agent mode.
2. `MultiAgentSystem.process_query()` executes a LangGraph state machine.
3. Nodes (Researcher/Analyzer/Synthesizer/etc.) process intermediate state.
4. Reflection logic may refine output.
5. Agent trace stored and rendered in dashboard + explainability pages.

### 2.4 Explainability & Confidence
- Sources, relevance scores, citations, confidence breakdown produced via `ExplainabilityService` + `GroundingService`.
- UI clamps negative values for display reliability.

### 2.5 PII Scrubbing
- `pii_scrubber.py` wraps `scrubadub` for detection, replacement, and batch operations.
- Page shows scrubbed text, detected entities, and export options.

### 2.6 Metrics Tracking
- `MetricsTracker` records per-query stats in `PerformanceMetric` (tokens, latency, errors, relevance).
- Future extension: route-level dashboards, anomaly detection.

---
## 3. Directory & File-Level Detail

### 3.1 Entry Point
- `main.py`: Bootstraps Streamlit app; handles dynamic block width (authenticated vs unauthenticated), page routing, global error boundaries.

### 3.2 Pages (User Interface)
- `app/pages/dashboard.py`: Central chat UI; selects mode (RAG / Multi-Agent); binds current collection, stores chat history & explainability data.
- `app/pages/rag_uploader.py`: Upload, extract, preview, chunk, embed, persist documents; updates `current_collection` in session.
- `app/pages/pii_scrubber.py`: Tabs for scrub, detect-only, batch processing with file upload.
- `app/pages/admin.py`: Provider switch, Ollama health checks, embedding tunables, environment persistence (.env), resets, recommended models.
- `app/pages/explainability_dashboard.py`: Multi-tab drilldown (session overview, source attribution, agent execution timeline, confidence metrics).

### 3.3 LLM & Embeddings
- `core/llm/llm_config.py`:
  - `get_llm()`: Returns `ChatOllama` or `ChatOpenAI` depending on `settings.llm_provider`.
  - Token counter wrapper for usage metrics.
- `core/llm/embeddings.py`:
  - `get_embeddings()`: Provider-aware instantiation: `OllamaEmbeddings` or `OpenAIEmbeddings`.
  - `embed_texts()` & `embed_query()`: Handles batching, safe retries, per-item fallback.
  - Tunables: batch size, retry count, delay, inter-batch delay.
- `core/llm/prompts.py`: Central registry of prompt templates (system + context formatting). Extend for new roles or domain-specific instructions.

### 3.4 Agents (Multi-Agent System)
- `core/agents/agent_graph.py`: Builds LangGraph `StateGraph`; defines nodes, edges, and compile process.
- `core/agents/agent_nodes.py`: Node functions performing specialized transformations, retrieval, synthesis.
- `core/agents/agent_tools.py`: LangChain `@tool` functions accessible to agents (e.g., search utilities, transformation helpers).
- `core/agents/reflection.py`: Post-pass critique or refinement (e.g. self-evaluation, improvement suggestions).
- `core/agents/visualizer.py`: Optional utilities for graph state inspection.

### 3.5 Services (Business Logic)
- `services/document_processor.py`: Extraction, text cleaning, sentence splitting, chunking with overlap, metadata builder.
- `services/vector_store.py`: ChromaDB singleton; collection management; add/search (similarity & MMR); converts distances to similarity scores; retrieval filtering.
- `services/rag_service.py`: Orchestrates retrieval + answer generation + metrics.
- `services/grounding.py`: Confidence estimation, hallucination heuristics, citation formatting.
- `services/explainability.py`: Attribution objects, content previews, confidence breakdown (completeness, diversity, relevance, count).
- `services/conversation_service.py`: Placeholder/foundation for storing full conversation transcripts; possible future summarization backend.
- `services/cache_service.py`: Optional caching (flagged by settings) for expensive operations (to extend).
- `services/pii_scrubber.py`: PII entity detection, cleansing, reporting.

### 3.6 Persistence (Models)
- `models/user.py`: User auth data (email, hashed password, roles).
- `models/document.py`: Uploaded document metadata (collection, chunk count, size, timestamps).
- `models/conversation.py`: History entries (speaker, content, metadata).
- `models/metrics.py`: Performance metrics for queries and embeddings.

### 3.7 Utilities
- `utils/auth.py`: JWT token creation/verification, password hashing (bcrypt), decorators.
- `utils/session.py`: Session state management (chat history, explainability data, agent traces, navigation helpers) + `require_auth` / `require_admin`.
- `utils/logger.py`: Central log configuration (file + level); consistent structured logging calls.
- `utils/validators.py`: File input validation (size/type), reusable for additional content gates.
- `utils/metrics.py`: Token usage counters, metric recording helper.
- `utils/ollama_helper.py`: Connectivity tests, model inventory, test calls, recommended models, size formatting.

### 3.8 Configuration
- `config/settings.py`: Pydantic-powered environment loader; provider fields; embedding tunables; path resolution; directory creation; warnings aggregator.
- `.env`: Runtime overrides for settings; updated via Admin panel.
- `.streamlit/config.toml`: Streamlit server behavior (file watcher, theme, port).
- `config/prompts.py`: Defines canonical prompts for RAG and multi-agent tasks.

### 3.9 Static & Styling
- `static/custom.css`: Corporate theme (colors, layout adjustments, typography, responsive tweaks); applied via `main.py` and global containers.

### 3.10 Documentation
- `docs/OLLAMA_SETUP.md`: Step-by-step guide for installing, pulling, and configuring Ollama models.
- `docs/OLLAMA_INTEGRATION.md`: Implementation details and environment variables.
- `docs/ARCHITECTURE.md`: (This document) canonical architecture reference.

---
## 4. Provider Abstraction Strategy

| Aspect | OpenAI Path | Ollama Path |
|--------|-------------|-------------|
| Chat Model | `ChatOpenAI` | `ChatOllama` |
| Embeddings | `OpenAIEmbeddings` | `OllamaEmbeddings` |
| API Key | Required | Dummy placeholder (`"ollama"`) |
| Base URL | Custom/remote endpoint | Local host (default `http://localhost:11434`) |
| Retry Logic | Network/transient | Local cold/warm starts & EOF fallbacks |
| Admin Controls | API/Model/Base URL | Base URL + LLM/Embedding models + performance tunables |

Switching provider updates `.env` (via Admin) and requires restart for full effect; `get_llm()`/`get_embeddings()` select logic based on `settings.llm_provider`.

---
## 5. Embedding Resilience

Challenges with local models (Ollama): transient EOF/500 during model warm-up or resource contention. Mitigations:
- Warm-up single query before heavy batch.
- Batch sizing with tunables (default 16; reduce to 8 for large docs).
- Per-batch delay to regulate local server load.
- Retry attempts + delay per batch and per-item fallback.
- Fallback sequential embedding ensures progress rather than total failure.

Extension Idea: Add circuit breaker to temporarily pause embedding if error rate spikes.

---
## 6. Retrieval Strategies

Currently:
- **Similarity Search:** Standard nearest neighbor by embedding distance (converted to similarity score = 1 - distance).
- **MMR Search:** Diversifies results balancing relevance vs novelty (lambda controls trade-off).

Future Extensions:
- Hybrid (BM25 + embeddings).
- Reranking with LLM or cross-encoder.
- Temporal or semantic filters.
- Collection-level ACL or domain tagging.

---
## 7. Explainability & Confidence

Components:
- **Source Attribution:** Each source chunk annotated with filename, chunk index, relevance, preview.
- **Confidence Breakdown:** Overall confidence computed from source count, diversity, relevance, completeness.
- **Execution Trace (Multi-Agent):** Steps with agent/action outputs serialized into session state.
- **Clamping:** Negative or >1 numeric values safely bounded for UI rendering.

Possible Enhancements:
- Token-level attribution via attention maps (requires model introspection).
- Explainable retrieval ordering (expose why a chunk was prioritized).
- Quality alerts when confidence < threshold.

---
## 8. Metrics & Observability

Tracked Per Query:
- Latency (ms)
- Total / prompt / completion tokens
- Number of retrieved docs
- Average relevance score
- Errors (with message)

Extensions:
- Token cost estimation (if provider has pricing).
- Per-user/month usage dashboards.
- Embedding latency buckets.
- Alerts on error spike or slow queries.

---
## 9. Security & Privacy Considerations

- Local LLM mode eliminates external data transfer (privacy advantage).
- PII scrubbing before embedding prevents sensitive vectors leaving system boundaries.
- JWT secret must be rotated for production; current default is a placeholder.
- Role-based restrictions enforced via `require_admin` decorator.
- Add CSRF or additional session safeguards if moving beyond Streamlit’s ephemeral sessions.

---
## 10. Extension Patterns

| Goal | Where to Add | Steps |
|------|--------------|-------|
| New Page | `app/pages/` | Create `page.py`, add navigation entry in `main.py`, optional session hooks. |
| New Agent | `core/agents/agent_nodes.py` | Implement node fn, register in `agent_graph.py`. |
| New Tool | `core/agents/agent_tools.py` | Add `@tool` function, reference in node logic. |
| New Provider | `config/settings.py` + `core/llm/` | Add settings fields, branch in `get_llm()`/`get_embeddings()`, Admin UI inputs. |
| New Doc Type | `services/document_processor.py` | Implement extractor, extend `extract_text`. |
| Retrieval Strategy | `services/vector_store.py` | Add method + UI toggle, call from `RAGService`. |
| Confidence Factor | `services/explainability.py` | Extend breakdown method + add UI display logic. |
| Metrics Dimension | `models/metrics.py` | Add field, adapt `MetricsTracker.record_metric`. |

Best Practices:
- Keep public interfaces stable; use composition over modifying core function signatures widely.
- Avoid side effects in getters (idempotent initialization only).
- Log errors with context (operation, user id, collection) for traceability.

---
## 11. Testing Strategy (Recommended)

Categories:
- **Unit:** Chunking, extraction, embedding fallback, MMR logic.
- **Integration:** End-to-end RAG query (mock LLM), document upload + retrieval.
- **Provider Switching:** Ensure both OpenAI and Ollama paths produce embeddings and answers.
- **Explainability:** Source attribution accuracy vs retrieved docs.

Tooling:
- Add Pytest config, fixtures for temporary ChromaDB path & SQLite file.
- Mock LLM responses to ensure deterministic outputs.

---
## 12. Deployment Notes

Local Development:
- Ensure Ollama installed & models pulled: `ollama pull llama3.2`, `ollama pull nomic-embed-text`.
- Run app: `streamlit run main.py`.
- Adjust embedding tunables in Admin for hardware limits.

Production Considerations:
- Reverse proxy (Nginx) in front of Streamlit.
- Scheduled cleanup of stale ChromaDB collections.
- Automated embedding model warm-up at startup.
- Add health endpoints for uptime monitoring.

---
## 13. Known Trade-Offs & Future Work

| Area | Current State | Improvement |
|------|---------------|------------|
| Embedding Stability | Retry + fallback | Circuit breaker, queue-based embedding worker |
| Retrieval Quality | Pure similarity/MMR | Hybrid, reranking, semantic filters |
| Multi-Agent Complexity | Basic node orchestration | Dynamic routing based on intermediate scoring |
| Explainability Depth | Chunk-level & agent trace | Token-level attribution, model rationale extraction |
| Auth & Roles | Basic admin flag | Granular RBAC per collection or feature |
| Observability | Metrics model & logging | Prometheus integration, dashboards |

---
## 14. Glossary
- **RAG:** Combine external retrieved context with LLM generation.
- **MMR:** Maximal Marginal Relevance, balances relevance and diversity.
- **Chunk:** A segmented piece of document text used for embedding.
- **Embedding:** Numeric vector representation of text used for similarity search.
- **Agent Trace:** Sequence of steps each agent took in a multi-agent workflow.
- **Grounding:** Anchoring generated output to verified sources to reduce hallucination.

---
## 15. Quick Start for New Contributors
1. Clone repo, create virtual environment, install dependencies (`pip install -r requirements.txt`).
2. Copy `.env.example` → `.env`, adjust provider settings.
3. Pull Ollama models (if using local mode).
4. Run `streamlit run main.py`.
5. Upload a small TXT file via RAG Uploader.
6. Ask a question in Dashboard; view sources & explainability.
7. Explore Admin panel—switch provider, test embedding parameters.
8. Add a test agent node to understand multi-agent flow.
9. Read this `ARCHITECTURE.md` + `OLLAMA_SETUP.md` for deeper platform understanding.

---
## 16. Safe Extension Checklist
Before committing a change:
- [ ] Does it keep existing public interfaces stable?
- [ ] Are new settings documented in Admin + `settings.py`?
- [ ] Are retries/backoffs appropriate for any new external calls?
- [ ] Are errors logged with clear context?
- [ ] Does it avoid blocking the UI (long operations should show spinners)?
- [ ] Is sensitive data scrubbed before vectorization?

---
## 17. Support & Maintenance Tips
- Periodically prune unused collections to reduce storage.
- Rotate JWT secret for production deployments.
- Monitor embedding latency; tune batch size downward if spikes occur.
- Keep dependencies updated within version ranges (especially LangChain / LangGraph).
- Document any domain-specific prompt changes in `prompts.py` comments.

---
## 18. Environment Variables Summary (Excerpt)
| Variable | Purpose | Example |
|----------|---------|---------|
| LLM_PROVIDER | Provider selection | `ollama` |
| OLLAMA_BASE_URL | Local LLM host | `http://localhost:11434` |
| OLLAMA_LLM_MODEL | LLM model name | `llama3.2` |
| OLLAMA_EMBEDDING_MODEL | Embedding model | `nomic-embed-text` |
| EMBEDDING_BATCH_SIZE | Embedding batch size | `16` |
| EMBEDDING_RETRY_ATTEMPTS | Retry count | `5` |
| EMBEDDING_RETRY_DELAY_SEC | Delay between retries | `0.75` |
| EMBEDDING_BATCH_DELAY_MS | Delay between batches | `75` |
| CHUNK_SIZE | Document chunk size | `1000` |
| CHUNK_OVERLAP | Overlap between chunks | `200` |
| MAX_TOKENS | Generation token budget | `4000` |
| TEMPERATURE | LLM creativity | `0.7` |

Full list: see `config/settings.py` and `.env`.

---
## 19. Final Notes
This architecture balances flexibility and clarity. When extending:
- Favor additive strategies (new service/module) over modifying many existing structures.
- Keep logic pure and side-effect free where possible (easy testability).
- Ensure all state passed through well-defined interfaces (services, agents, LLM functions).

For questions about deeper agent route customization or model-specific optimization, start by inspecting `core/agents/agent_graph.py` and experiment with adding intermediate verification nodes.

---
*End of Architecture Document.*
