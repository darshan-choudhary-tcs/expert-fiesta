"""
Setup Script for Development
Run this to initialize the development environment
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))


def setup_database():
    """Initialize database with tables"""
    print("Initializing database...")
    from models import init_db
    init_db()
    print("Database initialized")


def create_sample_user():
    """Create legacy sample admin user (backward compatibility)"""
    print("Ensuring legacy admin user exists...")
    from utils.auth import AuthService
    from models.user import get_session, User
    session = get_session()
    try:
        existing = session.query(User).filter(User.username == "admin").first()
        if existing:
            print("Admin user already exists")
            return
    finally:
        session.close()

    success, message, user = AuthService.register_user(
        username="admin",
        email="admin@example.com",
        password="Admin123!",
        full_name="System Administrator",
        role="admin"
    )
    if success:
        print("Admin user created: username=admin, password=Admin123!")
    else:
        print(f"Failed to create admin user: {message}")


def create_sample_role_users():
    """Seed sample users for each role (admin, editor, user) idempotently."""
    print("Seeding role-based sample users...")
    from utils.auth import AuthService
    from models.user import get_session, User
    session = get_session()
    try:
        seed_specs = [
            {"username": "admin", "email": "admin@example.com", "password": "Admin123!", "full_name": "System Administrator", "role": "admin"},
            {"username": "editor", "email": "editor@example.com", "password": "Editor123!", "full_name": "Content Editor", "role": "editor"},
            {"username": "userdemo", "email": "user@example.com", "password": "User123!", "full_name": "Demo User", "role": "user"},
        ]
        for spec in seed_specs:
            existing = session.query(User).filter(User.username == spec["username"]).first()
            if existing:
                print(f"{spec['username']} already exists (role={getattr(existing, 'role', 'unknown')})")
                continue
            success, message, _ = AuthService.register_user(
                username=spec["username"],
                email=spec["email"],
                password=spec["password"],
                full_name=spec["full_name"],
                role=spec["role"]
            )
            if success:
                print(f"Created {spec['role']} user: {spec['username']} / {spec['password']}")
            else:
                print(f"Failed to create {spec['username']}: {message}")
    finally:
        session.close()


def check_environment():
    """Check if environment is properly configured"""
    print("Checking environment...")
    from config.settings import settings

    warnings = settings.validate_settings()

    if warnings:
        print("Configuration warnings:")
        for warning in warnings:
            print(f"   - {warning}")
    else:
        print("Configuration looks good")

    return len(warnings) == 0


def test_llm_connection():
    """Test LLM connection"""
    print("Testing LLM connection...")
    try:
        from core.llm.llm_config import test_llm_connection
        success, message = test_llm_connection()
        if success:
            print(f"{message}")
        else:
            print(f"{message}")
        return success
    except Exception as e:
        print(f"LLM test failed: {e}")
        return False


def test_embeddings():
    """Test embeddings"""
    print("Testing embeddings...")
    try:
        from core.llm.embeddings import test_embeddings
        success, message = test_embeddings()
        if success:
            print(f"{message}")
        else:
            print(f"{message}")
        return success
    except Exception as e:
        print(f"Embeddings test failed: {e}")
        return False


def create_sample_documents():
    """Create sample documents in vector store"""
    print("Creating sample documents...")
    try:
        from services.vector_store import VectorStoreService

        vector_store = VectorStoreService("default")

        sample_texts = [
            "Python is a high-level, interpreted programming language known for its simplicity and readability.",
            "Machine learning is a subset of artificial intelligence that enables systems to learn from data.",
            "Natural language processing (NLP) is a field of AI focused on enabling computers to understand human language.",
            "Deep learning uses neural networks with multiple layers to process complex patterns in data.",
            "RAG (Retrieval-Augmented Generation) combines information retrieval with text generation."
        ]

        metadatas = [
            {'filename': 'sample.txt', 'chunk_index': i, 'total_chunks': len(sample_texts)}
            for i in range(len(sample_texts))
        ]

        vector_store.add_documents(sample_texts, metadatas)
        print(f"Added {len(sample_texts)} sample documents to vector store")
        return True
    except Exception as e:
        print(f"Failed to create sample documents: {e}")
        return False


def main():
    """Main setup function"""
    print("=" * 60)
    print("GenAI Hackathon Boilerplate - Setup")
    print("=" * 60)
    print()

    # Check environment
    env_ok = check_environment()
    print()

    # Setup database
    try:
        setup_database()
        print()
    except Exception as e:
        print(f"Database setup failed: {e}")
        print()

    # Create sample users (admin/editor/user)
    try:
        create_sample_user()  # legacy admin
        create_sample_role_users()
        print()
    except Exception as e:
        print(f"Sample user creation failed: {e}")
        print()

    # Test connections (only if environment is configured)
    if env_ok:
        llm_ok = test_llm_connection()
        print()

        embeddings_ok = test_embeddings()
        print()

        # Create sample documents (only if embeddings work)
        if embeddings_ok:
            create_sample_documents()
            print()
    else:
        print("Skipping connection tests - please configure .env file first")
        print()

    print("=" * 60)
    print("Setup Complete!")
    print("=" * 60)
    print()
    print("Next steps:")
    print("1. Copy .env.example to .env and configure your API keys")
    print("2. Run: streamlit run main.py")
    print("3. Login with one of:")
    print("   - admin / Admin123! (admin)")
    print("   - editor / Editor123! (editor)")
    print("   - userdemo / User123! (user)")
    print()


if __name__ == "__main__":
    main()
