"""
Agent Nodes
Individual agent implementations for the multi-agent system
"""

from typing import Dict, Any, List, TypedDict, Optional
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from core.llm.llm_config import get_llm
from core.llm.prompts import (
    get_agent_router_prompt,
    get_researcher_prompt,
    get_analyzer_prompt,
    get_synthesizer_prompt,
    get_reflection_prompt
)
from core.agents.agent_tools import AGENT_TOOLS, search_documents
from utils.logger import log_info, log_error


class AgentState(TypedDict, total=False):
    """State passed between agents"""
    query: str
    context: str
    intermediate_steps: List[str]
    final_answer: str
    confidence: float
    agent_trace: List[Dict]
    selected_agent: Optional[str]
    reflection: Optional[str]
    approved: Optional[bool]


def router_agent(state: AgentState) -> AgentState:
    """Route query to appropriate specialized agent"""
    try:
        log_info("Router agent processing query")

        prompt = get_agent_router_prompt()
        router_prompt = prompt.format(query=state.get('query', ''))

        llm = get_llm(temperature=0.1)
        response = llm.invoke(router_prompt)
        agent_choice = response.content.strip().upper()

        # Validate agent choice
        if agent_choice not in ['RESEARCHER', 'ANALYZER', 'SYNTHESIZER']:
            agent_choice = 'SYNTHESIZER'  # Default

        state['selected_agent'] = agent_choice
        state['agent_trace'] = state.get('agent_trace', [])
        state['agent_trace'].append({
            'agent': 'Router',
            'action': f'Selected {agent_choice}',
            'reasoning': response.content
        })

        log_info(f"Routed to {agent_choice}")
        return state

    except Exception as e:
        log_error(f"Router agent error: {e}")
        state['selected_agent'] = 'SYNTHESIZER'
        return state


def researcher_agent(state: AgentState) -> AgentState:
    """Research specialist agent"""
    try:
        log_info("Researcher agent gathering information")

        query = state.get('query', '')
        context = state.get('context', '')

        # Search for relevant documents
        search_results = search_documents(query)

        # Generate research findings
        prompt = get_researcher_prompt()
        research_prompt = prompt.format(query=query, context=context + "\n\n" + search_results)

        llm = get_llm()
        response = llm.invoke(research_prompt)

        state['context'] = state.get('context', '') + "\n\nResearch Findings:\n" + response.content
        state['intermediate_steps'] = state.get('intermediate_steps', [])
        state['intermediate_steps'].append(f"Researcher: {response.content[:200]}...")

        state['agent_trace'] = state.get('agent_trace', [])
        state['agent_trace'].append({
            'agent': 'Researcher',
            'action': 'Gathered information',
            'output': response.content[:150]
        })

        return state

    except Exception as e:
        log_error(f"Researcher agent error: {e}")
        return state


def analyzer_agent(state: AgentState) -> AgentState:
    """Analytical specialist agent"""
    try:
        log_info("Analyzer agent processing")

        query = state.get('query', '')
        context = state.get('context', '')

        # Analyze the query and context
        prompt = get_analyzer_prompt()
        analysis_prompt = prompt.format(query=query, context=context)

        llm = get_llm()
        response = llm.invoke(analysis_prompt)

        state['context'] = state.get('context', '') + "\n\nAnalysis:\n" + response.content
        state['intermediate_steps'] = state.get('intermediate_steps', [])
        state['intermediate_steps'].append(f"Analyzer: {response.content[:200]}...")

        state['agent_trace'] = state.get('agent_trace', [])
        state['agent_trace'].append({
            'agent': 'Analyzer',
            'action': 'Analyzed information',
            'output': response.content[:150]
        })

        return state

    except Exception as e:
        log_error(f"Analyzer agent error: {e}")
        return state


def synthesizer_agent(state: AgentState) -> AgentState:
    """Synthesis specialist agent - creates final response"""
    try:
        log_info("Synthesizer agent generating response")

        query = state.get('query', '')
        context = state.get('context', '')

        # Synthesize final answer
        prompt = get_synthesizer_prompt()
        synthesis_prompt = prompt.format(query=query, context=context)

        llm = get_llm()
        response = llm.invoke(synthesis_prompt)

        state['final_answer'] = response.content
        state['agent_trace'] = state.get('agent_trace', [])
        state['agent_trace'].append({
            'agent': 'Synthesizer',
            'action': 'Generated final response',
            'output': response.content[:150]
        })

        return state

    except Exception as e:
        log_error(f"Synthesizer agent error: {e}")
        state['final_answer'] = "An error occurred during synthesis."
        return state


def reflection_agent(state: AgentState) -> AgentState:
    """Quality assurance and reflection agent"""
    try:
        log_info("Reflection agent reviewing response")

        query = state.get('query', '')
        response = state.get('final_answer', '')

        # Reflect on the quality
        prompt = get_reflection_prompt()
        reflection_prompt = prompt.format(query=query, response=response)

        llm = get_llm(temperature=0.2)
        reflection = llm.invoke(reflection_prompt)

        # Check if approved
        approved = "YES" in reflection.content.upper() or "APPROVED: YES" in reflection.content.upper()

        state['reflection'] = reflection.content
        state['approved'] = approved
        state['agent_trace'] = state.get('agent_trace', [])
        state['agent_trace'].append({
            'agent': 'Reflection',
            'action': 'Quality review',
            'approved': approved,
            'feedback': reflection.content[:150]
        })

        return state

    except Exception as e:
        log_error(f"Reflection agent error: {e}")
        state['approved'] = True  # Default to approved on error
        return state
