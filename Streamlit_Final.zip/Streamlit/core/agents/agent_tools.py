"""
Agent Tools
Custom tools for agents to use
"""

from langchain_core.tools import tool
from typing import List, Dict, Any, Optional
from services.vector_store import VectorStoreService
from utils.logger import log_info


@tool
def search_documents(query: str, collection_name: str = "default", k: int = 3) -> str:
    """
    Search through vector database for relevant documents.

    Args:
        query: Search query
        collection_name: Name of collection to search
        k: Number of results to return

    Returns:
        String with search results
    """
    try:
        vector_store = VectorStoreService(collection_name)
        results = vector_store.similarity_search(query, k=k)

        if not results:
            return "No relevant documents found."

        output = f"Found {len(results)} relevant documents:\n\n"
        for i, doc in enumerate(results, 1):
            filename = doc.get('metadata', {}).get('filename', 'Unknown')
            score = doc.get('score', 0)
            content = doc.get('document', '')[:300]
            output += f"{i}. {filename} (relevance: {score:.2f})\n{content}...\n\n"

        return output
    except Exception as e:
        return f"Error searching documents: {str(e)}"


@tool
def analyze_text(text: str) -> str:
    """
    Analyze text for key information, sentiment, and themes.

    Args:
        text: Text to analyze

    Returns:
        Analysis results
    """
    # Simple analysis
    word_count = len(text.split())
    sentence_count = len([s for s in text.split('.') if s.strip()])

    # Extract potential keywords (simple frequency analysis)
    words = text.lower().split()
    word_freq = {}
    for word in words:
        if len(word) > 4:  # Only longer words
            word_freq[word] = word_freq.get(word, 0) + 1

    top_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:5]

    analysis = f"""Text Analysis:
- Word Count: {word_count}
- Sentence Count: {sentence_count}
- Average Words per Sentence: {word_count/max(sentence_count, 1):.1f}
- Top Keywords: {', '.join([w[0] for w in top_words])}
"""
    return analysis


@tool
def calculate(expression: str) -> str:
    """
    Perform mathematical calculations.

    Args:
        expression: Mathematical expression to evaluate

    Returns:
        Calculation result
    """
    try:
        # Safe evaluation (limited)
        result = eval(expression, {"__builtins__": {}}, {})
        return f"Result: {result}"
    except Exception as e:
        return f"Calculation error: {str(e)}"


# List of all available tools
AGENT_TOOLS = [search_documents, analyze_text, calculate]


def get_tool_descriptions() -> str:
    """Get descriptions of all available tools"""
    descriptions = []
    for tool in AGENT_TOOLS:
        descriptions.append(f"- {tool.name}: {tool.description}")
    return "\n".join(descriptions)
