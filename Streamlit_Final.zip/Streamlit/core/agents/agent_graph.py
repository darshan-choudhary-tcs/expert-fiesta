"""
Agent Graph
LangGraph-based multi-agent orchestration
"""

from typing import Dict, Any, TypedDict
from langgraph.graph import StateGraph, END
from core.agents.agent_nodes import (
    AgentState,
    router_agent,
    researcher_agent,
    analyzer_agent,
    synthesizer_agent,
    reflection_agent
)
from utils.logger import log_info, log_error


def create_agent_graph() -> StateGraph:
    """
    Create the multi-agent workflow graph

    Flow:
    1. Router → Select appropriate agent
    2. Specialized Agent (Researcher/Analyzer) → Process query
    3. Synthesizer → Generate final response
    4. Reflection → Quality check
    """

    # Create workflow graph
    workflow = StateGraph(AgentState)

    # Add nodes
    workflow.add_node("router", router_agent)
    workflow.add_node("researcher", researcher_agent)
    workflow.add_node("analyzer", analyzer_agent)
    workflow.add_node("synthesizer", synthesizer_agent)
    workflow.add_node("reflection", reflection_agent)

    # Also consider council of agents for complex tasks as future enhancement
    # Add a critique agent for each specialized agent (optional)

    # Define routing logic
    def route_to_specialist(state: AgentState) -> str:
        """Route based on router's decision"""
        selected = state.get('selected_agent', 'SYNTHESIZER')
        if selected == 'RESEARCHER':
            return "researcher"
        elif selected == 'ANALYZER':
            return "analyzer"
        else:
            return "synthesizer"

    # Add edges
    workflow.add_conditional_edges(
        "router",
        route_to_specialist,
        {
            "researcher": "researcher",
            "analyzer": "analyzer",
            "synthesizer": "synthesizer"
        }
    )

    # Specialized agents → Synthesizer
    workflow.add_edge("researcher", "synthesizer")
    workflow.add_edge("analyzer", "synthesizer")

    # Synthesizer → Reflection
    workflow.add_edge("synthesizer", "reflection")

    # Reflection → END
    workflow.add_edge("reflection", END)

    # Set entry point
    workflow.set_entry_point("router")

    # Compile graph
    app = workflow.compile()

    log_info("Agent graph created successfully")
    return app


class MultiAgentSystem:
    """Wrapper for multi-agent system"""

    def __init__(self):
        self.graph = create_agent_graph()

    def process_query(self, query: str, context: str = "") -> Dict[str, Any]:
        """
        Process a query through the multi-agent system

        Args:
            query: User query
            context: Optional context

        Returns:
            Dict with answer and execution trace
        """
        try:
            log_info(f"Processing query through multi-agent system: {query[:50]}...")

            # Initialize state as dict (TypedDict is just a type hint)
            initial_state = {
                "query": query,
                "context": context,
                "intermediate_steps": [],
                "final_answer": "",
                "confidence": 0.0,
                "agent_trace": []
            }

            # Execute graph
            final_state = self.graph.invoke(initial_state)

            return {
                'answer': final_state.get('final_answer', 'No answer generated'),
                'agent_trace': final_state.get('agent_trace', []),
                'intermediate_steps': final_state.get('intermediate_steps', []),
                'reflection': final_state.get('reflection', ''),
                'approved': final_state.get('approved', True),
                'selected_agent': final_state.get('selected_agent', 'UNKNOWN')
            }

        except Exception as e:
            log_error(f"Multi-agent system error: {e}", exc_info=True)
            return {
                'answer': f"Error processing query: {str(e)}",
                'agent_trace': [],
                'intermediate_steps': [],
                'error': str(e)
            }

    def get_graph_visualization(self) -> str:
        """Get Mermaid diagram of agent graph"""
        mermaid = """graph TD
    A[Start] --> B[Router Agent]
    B -->|Research Query| C[Researcher Agent]
    B -->|Analysis Query| D[Analyzer Agent]
    B -->|General Query| E[Synthesizer Agent]
    C --> E
    D --> E
    E --> F[Reflection Agent]
    F --> G[End]
"""
        return mermaid
