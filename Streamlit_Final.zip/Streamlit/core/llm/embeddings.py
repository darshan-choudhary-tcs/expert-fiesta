"""
Embeddings Configuration
Sets up Embeddings with support for OpenAI and Ollama providers
"""

import httpx
from langchain_openai import OpenAIEmbeddings
from langchain_ollama import OllamaEmbeddings
from typing import List, Optional
from config.settings import settings
from utils.logger import log_info, log_error
import time
from httpx import HTTPError
import os


def get_embeddings() -> OpenAIEmbeddings:
    """
    Get configured Embeddings instance (OpenAI or Ollama based on provider)

    Returns:
        Configured OpenAIEmbeddings instance
    """
    try:
        provider = settings.llm_provider.lower()

        if provider == "ollama":
            # Configure for Ollama embeddings via native OllamaEmbeddings
            # Ensure correct host is used; override any env misconfiguration
            os.environ["OLLAMA_HOST"] = settings.ollama_base_url
            embeddings = OllamaEmbeddings(
                base_url=settings.ollama_base_url,
                model=settings.ollama_embedding_model,
            )
            log_info(f"Embeddings initialized (Ollama): {settings.ollama_embedding_model}")
        else:
            # Configure for OpenAI-compatible API (default)
            client = httpx.Client(verify=False)
            embeddings = OpenAIEmbeddings(
                base_url=settings.embedding_base_url,
                model=settings.embedding_model,
                api_key=settings.embedding_api_key,
                http_client=client
            )
            log_info(f"Embeddings initialized (OpenAI): {settings.embedding_model}")

        return embeddings

    except Exception as e:
        log_error(f"Error initializing embeddings: {e}", exc_info=True)
        raise


def embed_texts(texts: List[str], batch_size: int = None) -> List[List[float]]:
    """
    Embed a list of texts with batching support

    Args:
        texts: List of text strings to embed
        batch_size: Batch size for embedding (default 100)

    Returns:
        List of embedding vectors
    """
    try:
        embeddings = get_embeddings()

        # Pre-warm model to avoid first-call EOF while model loads
        try:
            _ = _retry_embed_query(embeddings, "warmup", retries=2, delay=0.5)
        except Exception:
            # Ignore warmup failure; proceed with normal flow
            pass

        # Determine batch size from settings if not provided
        bs = batch_size or settings.embedding_batch_size

        # Process in batches if needed
        if len(texts) <= bs:
            return _retry_embed_documents(embeddings, texts)

        all_embeddings = []
        for i in range(0, len(texts), bs):
            batch = texts[i:i + bs]
            # Small delay to avoid overloading local server
            time.sleep(max(0.0, settings.embedding_batch_delay_ms / 1000.0))
            try:
                batch_embeddings = _retry_embed_documents(
                    embeddings,
                    batch,
                    retries=settings.embedding_retry_attempts,
                    delay=settings.embedding_retry_delay_sec,
                )
            except Exception as e:
                # Fallback: embed each item sequentially with delay
                log_info(f"Batch embedding failed, falling back to per-item embedding: {e}")
                batch_embeddings = []
                for t in batch:
                    time.sleep(max(0.0, settings.embedding_batch_delay_ms / 1000.0))
                    vec = _retry_embed_query(
                        embeddings,
                        t,
                        retries=settings.embedding_retry_attempts,
                        delay=settings.embedding_retry_delay_sec,
                    )
                    batch_embeddings.append(vec)
            all_embeddings.extend(batch_embeddings)
            log_info(f"Embedded batch {i//bs + 1}/{(len(texts)-1)//bs + 1}")

        return all_embeddings

    except Exception as e:
        log_error(f"Error embedding texts: {e}", exc_info=True)
        raise


def embed_query(query: str) -> List[float]:
    """
    Embed a single query string

    Args:
        query: Query string to embed

    Returns:
        Embedding vector
    """
    try:
        embeddings = get_embeddings()
        return _retry_embed_query(embeddings, query)
    except Exception as e:
        log_error(f"Error embedding query: {e}", exc_info=True)
        raise


def test_embeddings() -> tuple[bool, str]:
    """
    Test embeddings connection

    Returns:
        Tuple of (success, message)
    """
    try:
        test_text = "This is a test sentence."
        embedding = embed_query(test_text)
        dimension = len(embedding)
        return True, f"Embeddings working. Dimension: {dimension}"
    except Exception as e:
        return False, f"Embeddings test failed: {str(e)}"


# Example usage
if __name__ == "__main__":
    print("Testing embeddings...")
    success, message = test_embeddings()
    print(f"Success: {success}")
    print(f"Message: {message}")


def _retry_embed_documents(embeddings: OpenAIEmbeddings | OllamaEmbeddings, texts: List[str], retries: int = 3, delay: float = 1.0) -> List[List[float]]:
    """
    Retry wrapper for embed_documents to handle transient EOF/500 errors.
    """
    last_err: Optional[Exception] = None
    for attempt in range(1, retries + 1):
        try:
            return embeddings.embed_documents(texts)
        except HTTPError as e:
            last_err = e
            log_error(f"embed_documents HTTP error (attempt {attempt}/{retries}): {e}")
        except Exception as e:
            last_err = e
            # Ollama may return EOF on first call while loading the model
            if "EOF" in str(e) or "status code: 500" in str(e):
                log_info(f"Transient embedding error (attempt {attempt}/{retries}): {e}. Retrying after {delay}s...")
            else:
                raise
        time.sleep(delay)
    # Exhausted retries
    raise RuntimeError(f"Failed to embed documents after {retries} attempts: {last_err}")


def _retry_embed_query(embeddings: OpenAIEmbeddings | OllamaEmbeddings, query: str, retries: int = 3, delay: float = 1.0) -> List[float]:
    """
    Retry wrapper for embed_query to handle transient EOF/500 errors.
    """
    last_err: Optional[Exception] = None
    for attempt in range(1, retries + 1):
        try:
            return embeddings.embed_query(query)
        except HTTPError as e:
            last_err = e
            log_error(f"embed_query HTTP error (attempt {attempt}/{retries}): {e}")
        except Exception as e:
            last_err = e
            if "EOF" in str(e) or "status code: 500" in str(e):
                log_info(f"Transient embedding error (attempt {attempt}/{retries}): {e}. Retrying after {delay}s...")
            else:
                raise
        time.sleep(delay)
    raise RuntimeError(f"Failed to embed query after {retries} attempts: {last_err}")
