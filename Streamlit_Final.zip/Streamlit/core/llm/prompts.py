"""
Prompt Templates
Centralized prompt templates for RAG, agents, and explainability
"""

from langchain_core.prompts import PromptTemplate, ChatPromptTemplate
from langchain_core.prompts.chat import SystemMessagePromptTemplate, HumanMessagePromptTemplate


# RAG System Prompt
RAG_SYSTEM_PROMPT = """You are a helpful AI assistant with access to relevant documents.
Your task is to answer questions based on the provided context documents.

IMPORTANT GUIDELINES:
1. Base your answers primarily on the provided context
2. If the context doesn't contain enough information, acknowledge this limitation
3. Cite specific sources when making claims
4. Be concise but comprehensive
5. If you're uncertain, express appropriate confidence levels

Context Documents:
{context}

Remember to ground your responses in the provided evidence."""


# RAG Question Template
RAG_QUESTION_TEMPLATE = """Based on the context provided above, please answer the following question:

Question: {question}

Provide a detailed answer with citations to relevant sources."""


# Agent Router Prompt
AGENT_ROUTER_PROMPT = """You are a routing agent that analyzes user queries and decides which specialized agent should handle them.

Available Agents:
1. RESEARCHER - For queries requiring information gathering, web search, or document analysis
2. ANALYZER - For queries requiring data analysis, comparison, or critical evaluation
3. SYNTHESIZER - For queries requiring combining multiple pieces of information or creative generation

Query: {query}

Analyze the query and respond with ONLY the agent name (RESEARCHER, ANALYZER, or SYNTHESIZER) that should handle this query.
Agent:"""


# Researcher Agent Prompt
RESEARCHER_AGENT_PROMPT = """You are a research specialist AI agent. Your role is to:
- Gather relevant information from available sources
- Search through documents and knowledge bases
- Identify key facts and evidence
- Organize findings in a structured way

Use the available tools to research the following query:
{query}

Context from previous steps (if any):
{context}

Provide your research findings in a clear, organized format."""


# Analyzer Agent Prompt
ANALYZER_AGENT_PROMPT = """You are an analytical AI agent. Your role is to:
- Critically evaluate information
- Compare and contrast different viewpoints
- Identify patterns and relationships
- Draw evidence-based conclusions

Analyze the following query using available tools:
{query}

Context from previous steps (if any):
{context}

Provide your analysis with clear reasoning and evidence."""


# Synthesizer Agent Prompt
SYNTHESIZER_AGENT_PROMPT = """You are a synthesis specialist AI agent. Your role is to:
- Combine information from multiple sources
- Generate coherent, comprehensive responses
- Create new insights from existing information
- Present findings in a user-friendly format

Synthesize a response for the following query:
{query}

Context from previous steps (if any):
{context}

Provide a well-structured, comprehensive response."""


# Reflection Agent Prompt
REFLECTION_PROMPT = """You are a quality assurance agent. Review the following response and assess:
1. Accuracy - Is the information correct and well-supported?
2. Completeness - Does it fully address the query?
3. Clarity - Is it well-organized and easy to understand?
4. Citations - Are sources properly referenced?

Query: {query}

Response to Review:
{response}

Provide your assessment and suggest improvements if needed. Format your response as:
QUALITY_SCORE: [1-10]
ISSUES: [List any problems]
SUGGESTIONS: [Improvement recommendations]
APPROVED: [YES/NO]"""


# Explainability Prompt
EXPLAINABILITY_PROMPT = """Explain the reasoning process for the following response:

Query: {query}

Response: {response}

Sources Used: {sources}

Provide a step-by-step explanation of:
1. How the query was interpreted
2. Which sources were considered most relevant and why
3. How the final answer was constructed
4. Confidence level and any limitations

Format your explanation clearly for non-technical users."""


# Grounding Verification Prompt
GROUNDING_VERIFICATION_PROMPT = """Verify if the following statement is grounded in the provided sources:

Statement: {statement}

Sources:
{sources}

Respond with:
GROUNDED: [YES/NO/PARTIAL]
CONFIDENCE: [0.0-1.0]
SUPPORTING_EVIDENCE: [Quote relevant passages]
EXPLANATION: [Brief explanation of your assessment]"""


# Fact Checking Prompt
FACT_CHECK_PROMPT = """Check the following claim against the provided context:

Claim: {claim}

Context:
{context}

Determine:
1. Is the claim supported by the context?
2. What is the confidence level?
3. What evidence supports or refutes the claim?

Respond in JSON format:
{
    "supported": true/false,
    "confidence": 0.0-1.0,
    "evidence": ["list", "of", "supporting", "quotes"],
    "explanation": "brief explanation"
}"""


# Create LangChain PromptTemplate objects
def get_rag_prompt() -> ChatPromptTemplate:
    """Get RAG chat prompt template"""
    return ChatPromptTemplate.from_messages([
        SystemMessagePromptTemplate.from_template(RAG_SYSTEM_PROMPT),
        HumanMessagePromptTemplate.from_template(RAG_QUESTION_TEMPLATE)
    ])


def get_agent_router_prompt() -> PromptTemplate:
    """Get agent router prompt template"""
    return PromptTemplate(
        input_variables=["query"],
        template=AGENT_ROUTER_PROMPT
    )


def get_researcher_prompt() -> PromptTemplate:
    """Get researcher agent prompt template"""
    return PromptTemplate(
        input_variables=["query", "context"],
        template=RESEARCHER_AGENT_PROMPT
    )


def get_analyzer_prompt() -> PromptTemplate:
    """Get analyzer agent prompt template"""
    return PromptTemplate(
        input_variables=["query", "context"],
        template=ANALYZER_AGENT_PROMPT
    )


def get_synthesizer_prompt() -> PromptTemplate:
    """Get synthesizer agent prompt template"""
    return PromptTemplate(
        input_variables=["query", "context"],
        template=SYNTHESIZER_AGENT_PROMPT
    )


def get_reflection_prompt() -> PromptTemplate:
    """Get reflection agent prompt template"""
    return PromptTemplate(
        input_variables=["query", "response"],
        template=REFLECTION_PROMPT
    )


def get_explainability_prompt() -> PromptTemplate:
    """Get explainability prompt template"""
    return PromptTemplate(
        input_variables=["query", "response", "sources"],
        template=EXPLAINABILITY_PROMPT
    )


def get_grounding_verification_prompt() -> PromptTemplate:
    """Get grounding verification prompt template"""
    return PromptTemplate(
        input_variables=["statement", "sources"],
        template=GROUNDING_VERIFICATION_PROMPT
    )


def get_fact_check_prompt() -> PromptTemplate:
    """Get fact checking prompt template"""
    return PromptTemplate(
        input_variables=["claim", "context"],
        template=FACT_CHECK_PROMPT
    )
