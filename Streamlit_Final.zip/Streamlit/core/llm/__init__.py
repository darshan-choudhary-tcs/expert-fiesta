"""
Core LLM Package Initializer
"""

from core.llm.llm_config import get_llm, get_llm_with_token_counter, test_llm_connection
from core.llm.embeddings import get_embeddings, embed_texts, embed_query, test_embeddings
from core.llm.prompts import (
    get_rag_prompt,
    get_agent_router_prompt,
    get_researcher_prompt,
    get_analyzer_prompt,
    get_synthesizer_prompt,
    get_reflection_prompt,
    get_explainability_prompt
)

__all__ = [
    'get_llm',
    'get_llm_with_token_counter',
    'test_llm_connection',
    'get_embeddings',
    'embed_texts',
    'embed_query',
    'test_embeddings',
    'get_rag_prompt',
    'get_agent_router_prompt',
    'get_researcher_prompt',
    'get_analyzer_prompt',
    'get_synthesizer_prompt',
    'get_reflection_prompt',
    'get_explainability_prompt'
]
