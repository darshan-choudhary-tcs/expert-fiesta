"""
LLM Configuration
Sets up the ChatOpenAI LLM with GenAI Lab configuration
"""

import httpx
from langchain_openai import ChatOpenAI
from langchain_ollama import ChatOllama
from langchain_core.callbacks.base import BaseCallbackHandler
from langchain_core.outputs import LLMResult
from typing import Any, Dict, List, Optional
from config.settings import settings
from utils.logger import log_info, log_error


class TokenCounterCallback(BaseCallbackHandler):
    """Callback to count tokens used in LLM calls"""

    def __init__(self):
        self.total_tokens = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0

    def on_llm_end(self, response: LLMResult, **kwargs: Any) -> None:
        """Track token usage"""
        if response.llm_output and 'token_usage' in response.llm_output:
            usage = response.llm_output['token_usage']
            self.total_tokens += usage.get('total_tokens', 0)
            self.prompt_tokens += usage.get('prompt_tokens', 0)
            self.completion_tokens += usage.get('completion_tokens', 0)

    def reset(self):
        """Reset token counters"""
        self.total_tokens = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0

    def get_usage(self) -> Dict[str, int]:
        """Get token usage stats"""
        return {
            'total_tokens': self.total_tokens,
            'prompt_tokens': self.prompt_tokens,
            'completion_tokens': self.completion_tokens
        }


def get_llm(
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    streaming: bool = False,
    callbacks: Optional[List[BaseCallbackHandler]] = None
) -> ChatOpenAI:
    """
    Get configured LLM instance (OpenAI or Ollama based on provider)

    Args:
        temperature: Temperature for generation (default from settings)
        max_tokens: Max tokens for generation (default from settings)
        streaming: Enable streaming responses
        callbacks: List of callback handlers

    Returns:
        Configured ChatOpenAI instance
    """
    try:
        provider = settings.llm_provider.lower()

        if provider == "ollama":
            # Use native Ollama chat model for reliability
            llm = ChatOllama(
                base_url=settings.ollama_base_url,
                model=settings.ollama_llm_model,
                temperature=temperature if temperature is not None else settings.temperature,
                num_predict=max_tokens if max_tokens is not None else settings.max_tokens,
                callbacks=callbacks or []
            )
            log_info(f"LLM initialized (Ollama): {settings.ollama_llm_model}")
        else:
            # Configure for OpenAI-compatible API (default)
            client = httpx.Client(verify=False)
            llm = ChatOpenAI(
                base_url=settings.llm_base_url,
                model=settings.llm_model,
                api_key=settings.llm_api_key,
                http_client=client,
                temperature=temperature if temperature is not None else settings.temperature,
                max_tokens=max_tokens if max_tokens is not None else settings.max_tokens,
                streaming=streaming,
                callbacks=callbacks or []
            )
            log_info(f"LLM initialized (OpenAI): {settings.llm_model}")
        return llm

    except Exception as e:
        log_error(f"Error initializing LLM: {e}", exc_info=True)
        raise


def get_llm_with_token_counter(
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    streaming: bool = False
) -> tuple[ChatOpenAI, TokenCounterCallback]:
    """
    Get LLM with token counter callback

    Returns:
        Tuple of (llm, token_counter)
    """
    token_counter = TokenCounterCallback()
    llm = get_llm(
        temperature=temperature,
        max_tokens=max_tokens,
        streaming=streaming,
        callbacks=[token_counter]
    )
    return llm, token_counter


def test_llm_connection() -> tuple[bool, str]:
    """
    Test LLM connection

    Returns:
        Tuple of (success, message)
    """
    try:
        llm = get_llm(max_tokens=10)
        response = llm.invoke("Say 'Hello'")
        return True, f"Connection successful. Response: {response.content}"
    except Exception as e:
        return False, f"Connection failed: {str(e)}"


# Example usage
if __name__ == "__main__":
    print("Testing LLM connection...")
    success, message = test_llm_connection()
    print(f"Success: {success}")
    print(f"Message: {message}")
