"""
Validation Utilities
Input validation and sanitization functions
"""

import re
from typing import Tuple


def validate_email(email: str) -> Tuple[bool, str]:
    """
    Validate email format
    Returns: (is_valid, error_message)
    """
    if not email:
        return False, "Email is required"

    # Basic email regex pattern
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

    if not re.match(pattern, email):
        return False, "Invalid email format"

    if len(email) > 100:
        return False, "Email is too long (max 100 characters)"

    return True, ""


def validate_username(username: str) -> Tuple[bool, str]:
    """
    Validate username format
    Returns: (is_valid, error_message)
    """
    if not username:
        return False, "Username is required"

    if len(username) < 3:
        return False, "Username must be at least 3 characters"

    if len(username) > 50:
        return False, "Username is too long (max 50 characters)"

    # Allow only alphanumeric and underscore
    if not re.match(r'^[a-zA-Z0-9_]+$', username):
        return False, "Username can only contain letters, numbers, and underscores"

    return True, ""


def validate_password(password: str) -> Tuple[bool, str]:
    """
    Validate password strength
    Returns: (is_valid, error_message)
    """
    if not password:
        return False, "Password is required"

    if len(password) < 8:
        return False, "Password must be at least 8 characters"

    if len(password) > 100:
        return False, "Password is too long (max 100 characters)"

    # Check for at least one uppercase letter
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"

    # Check for at least one lowercase letter
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"

    # Check for at least one digit
    if not re.search(r'\d', password):
        return False, "Password must contain at least one number"

    return True, ""


def validate_full_name(full_name: str) -> Tuple[bool, str]:
    """
    Validate full name
    Returns: (is_valid, error_message)
    """
    if not full_name:
        return True, ""  # Full name is optional

    if len(full_name) > 100:
        return False, "Full name is too long (max 100 characters)"

    # Allow letters, spaces, hyphens, and apostrophes
    if not re.match(r"^[a-zA-Z\s\-']+$", full_name):
        return False, "Full name can only contain letters, spaces, hyphens, and apostrophes"

    return True, ""


def validate_file_upload(filename: str, file_size: int, max_size_mb: int = 10) -> Tuple[bool, str]:
    """
    Validate uploaded file
    Returns: (is_valid, error_message)
    """
    if not filename:
        return False, "No file selected"

    # Check file extension
    allowed_extensions = ['pdf', 'txt', 'docx', 'doc']
    ext = filename.lower().split('.')[-1]

    if ext not in allowed_extensions:
        return False, f"File type not supported. Allowed: {', '.join(allowed_extensions)}"

    # Check file size
    max_size_bytes = max_size_mb * 1024 * 1024
    if file_size > max_size_bytes:
        return False, f"File size exceeds {max_size_mb}MB limit"

    return True, ""


def sanitize_string(text: str) -> str:
    """
    Sanitize string input by removing potentially harmful characters
    """
    if not text:
        return ""

    # Remove null bytes
    text = text.replace('\x00', '')

    # Strip leading/trailing whitespace
    text = text.strip()

    return text


def validate_query(query: str, max_length: int = 2000) -> Tuple[bool, str]:
    """
    Validate user query/prompt
    Returns: (is_valid, error_message)
    """
    if not query or not query.strip():
        return False, "Query cannot be empty"

    if len(query) > max_length:
        return False, f"Query is too long (max {max_length} characters)"

    return True, ""


def validate_session_id(session_id: str) -> bool:
    """Validate session ID format (UUID)"""
    if not session_id:
        return False

    # Check if it matches UUID format
    uuid_pattern = r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    return bool(re.match(uuid_pattern, session_id.lower()))
