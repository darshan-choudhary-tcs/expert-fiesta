"""
Session Management Utilities
Handles Streamlit session state and user session management
"""

import streamlit as st
from typing import Optional, Dict, Any
from functools import wraps
from utils.auth import AuthService


def init_session_state():
    """Initialize session state variables"""
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False

    if 'user' not in st.session_state:
        st.session_state.user = None

    if 'token' not in st.session_state:
        st.session_state.token = None

    if 'session_id' not in st.session_state:
        import uuid
        st.session_state.session_id = str(uuid.uuid4())

    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []

    if 'current_page' not in st.session_state:
        st.session_state.current_page = 'login'

    if 'explainability_data' not in st.session_state:
        st.session_state.explainability_data = None

    if 'agent_execution_trace' not in st.session_state:
        st.session_state.agent_execution_trace = []


def login_user(user_dict: Dict, token: str):
    """Log in a user and set session state"""
    st.session_state.authenticated = True
    st.session_state.user = user_dict
    st.session_state.token = token
    st.session_state.current_page = 'dashboard'


def logout_user():
    """Log out the current user"""
    st.session_state.authenticated = False
    st.session_state.user = None
    st.session_state.token = None
    st.session_state.chat_history = []
    st.session_state.explainability_data = None
    st.session_state.agent_execution_trace = []
    st.session_state.current_page = 'login'


def get_current_user() -> Optional[Dict]:
    """Get the currently logged-in user"""
    return st.session_state.get('user', None)


def get_current_user_id() -> Optional[int]:
    """Get the current user's ID"""
    user = get_current_user()
    return user.get('id') if user else None


def is_authenticated() -> bool:
    """Check if user is authenticated"""
    return st.session_state.get('authenticated', False)


def is_admin() -> bool:
    """Check if current user is admin"""
    user = get_current_user()
    return user.get('is_admin', False) if user else False


def get_current_role() -> str:
    user = get_current_user()
    return user.get('role', 'user') if user else 'anonymous'


def has_role(roles) -> bool:
    role = get_current_role()
    if isinstance(roles, (list, tuple, set)):
        return role in roles
    return role == roles


def require_auth(func):
    """Decorator to require authentication for a function"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not is_authenticated():
            st.warning("Please log in to access this page")
            st.stop()
        return func(*args, **kwargs)
    return wrapper


def require_admin(func):
    """Decorator to require admin privileges"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not is_authenticated():
            st.warning("Please log in to access this page")
            st.stop()
        if not has_role({'admin'}):
            st.error("Admin access required")
            st.stop()
        return func(*args, **kwargs)
    return wrapper


def require_editor(func):
    """Decorator to require editor or admin role"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not is_authenticated():
            st.warning("Please log in to access this page")
            st.stop()
        if not has_role({'editor', 'admin'}):
            st.error("Editor access required")
            st.stop()
        return func(*args, **kwargs)
    return wrapper


def require_roles(roles):
    """Generic decorator for requiring one of several roles."""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not is_authenticated():
                st.warning("Please log in to access this page")
                st.stop()
            if not has_role(set(roles)):
                st.error(f"Access requires one of: {', '.join(roles)}")
                st.stop()
            return func(*args, **kwargs)
        return wrapper
    return decorator


def add_to_chat_history(role: str, content: str, metadata: Dict[str, Any] = None):
    """Add a message to chat history"""
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []

    message = {
        'role': role,
        'content': content,
        'metadata': metadata or {},
        'timestamp': st.session_state.get('session_id', 'unknown')
    }
    st.session_state.chat_history.append(message)


def clear_chat_history():
    """Clear the chat history"""
    st.session_state.chat_history = []
    st.session_state.explainability_data = None
    st.session_state.agent_execution_trace = []


def get_chat_history() -> list:
    """Get the chat history"""
    return st.session_state.get('chat_history', [])


def set_explainability_data(data: Dict[str, Any]):
    """Set explainability data for the last response"""
    st.session_state.explainability_data = data


def get_explainability_data() -> Optional[Dict[str, Any]]:
    """Get explainability data"""
    return st.session_state.get('explainability_data', None)


def add_agent_trace(agent_name: str, action: str, result: Any):
    """Add an agent execution trace"""
    if 'agent_execution_trace' not in st.session_state:
        st.session_state.agent_execution_trace = []

    trace = {
        'agent': agent_name,
        'action': action,
        'result': str(result)[:200],  # Truncate long results
        'timestamp': st.session_state.get('session_id', 'unknown')
    }
    st.session_state.agent_execution_trace.append(trace)


def get_agent_traces() -> list:
    """Get agent execution traces"""
    return st.session_state.get('agent_execution_trace', [])


def clear_agent_traces():
    """Clear agent execution traces"""
    st.session_state.agent_execution_trace = []


def navigate_to(page: str, rerun: bool = True):
    """
    Navigate to a specific page

    Args:
        page: Target page name
        rerun: Whether to trigger st.rerun() immediately (default True)
    """
    st.session_state.current_page = page
    if rerun:
        st.rerun()


def get_current_page() -> str:
    """Get the current page"""
    return st.session_state.get('current_page', 'login')
