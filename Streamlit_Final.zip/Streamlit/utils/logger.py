"""
Logging Utilities
Structured logging for application events and errors
"""

import logging
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional
from config.settings import settings


class CustomFormatter(logging.Formatter):
    """Custom formatter with colors for console output"""

    grey = "\x1b[38;21m"
    blue = "\x1b[38;5;39m"
    yellow = "\x1b[38;5;226m"
    red = "\x1b[38;5;196m"
    bold_red = "\x1b[31;1m"
    reset = "\x1b[0m"

    format_str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    FORMATS = {
        logging.DEBUG: grey + format_str + reset,
        logging.INFO: blue + format_str + reset,
        logging.WARNING: yellow + format_str + reset,
        logging.ERROR: red + format_str + reset,
        logging.CRITICAL: bold_red + format_str + reset
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt, datefmt='%Y-%m-%d %H:%M:%S')
        return formatter.format(record)


def setup_logger(name: str, log_file: Optional[str] = None, level: str = None) -> logging.Logger:
    """
    Set up a logger with console and file handlers

    Args:
        name: Logger name
        log_file: Optional log file path (uses settings if not provided)
        level: Log level (uses settings if not provided)

    Returns:
        Configured logger
    """
    logger = logging.getLogger(name)

    # Set log level
    log_level = level or settings.log_level
    logger.setLevel(getattr(logging, log_level.upper()))

    # Avoid duplicate handlers
    if logger.handlers:
        return logger

    # Console handler with custom formatter
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG)
    console_handler.setFormatter(CustomFormatter())
    logger.addHandler(console_handler)

    # File handler
    if log_file is None:
        log_file = settings.get_log_path()

    try:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)
    except Exception as e:
        print(f"Warning: Could not create file handler: {e}")

    return logger


# Create default application logger
app_logger = setup_logger('genai_app')


def log_info(message: str, logger_name: str = 'genai_app'):
    """Log info message"""
    logger = logging.getLogger(logger_name)
    logger.info(message)


def log_warning(message: str, logger_name: str = 'genai_app'):
    """Log warning message"""
    logger = logging.getLogger(logger_name)
    logger.warning(message)


def log_error(message: str, exc_info: bool = False, logger_name: str = 'genai_app'):
    """Log error message"""
    logger = logging.getLogger(logger_name)
    logger.error(message, exc_info=exc_info)


def log_debug(message: str, logger_name: str = 'genai_app'):
    """Log debug message"""
    logger = logging.getLogger(logger_name)
    logger.debug(message)


def log_exception(exception: Exception, context: str = "", logger_name: str = 'genai_app'):
    """Log exception with context"""
    logger = logging.getLogger(logger_name)
    if context:
        logger.exception(f"{context}: {str(exception)}")
    else:
        logger.exception(str(exception))


# Usage example:
# from utils.logger import setup_logger, log_info, log_error
# logger = setup_logger('my_module')
# logger.info("This is an info message")
# log_error("This is an error", exc_info=True)
