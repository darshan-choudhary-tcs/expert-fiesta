"""
Environment File Manager
Utilities for reading and updating .env file
"""

import os
from pathlib import Path
from typing import Dict, Optional


class EnvManager:
    """Manage .env file updates"""

    @staticmethod
    def get_env_path() -> Path:
        """Get the path to .env file"""
        # Get project root (parent of utils directory)
        current_dir = Path(__file__).parent
        project_root = current_dir.parent
        return project_root / ".env"

    @staticmethod
    def read_env_file() -> Dict[str, str]:
        """Read current .env file and return as dictionary"""
        env_path = EnvManager.get_env_path()
        env_vars = {}

        if env_path.exists():
            with open(env_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    # Skip empty lines and comments
                    if line and not line.startswith('#'):
                        if '=' in line:
                            key, value = line.split('=', 1)
                            env_vars[key.strip()] = value.strip()

        return env_vars

    @staticmethod
    def update_env_file(updates: Dict[str, str]) -> bool:
        """
        Update .env file with new values

        Args:
            updates: Dictionary of key-value pairs to update

        Returns:
            True if successful, False otherwise
        """
        try:
            env_path = EnvManager.get_env_path()

            # Read all lines
            lines = []
            if env_path.exists():
                with open(env_path, 'r') as f:
                    lines = f.readlines()

            # Update existing keys or add new ones
            updated_keys = set()
            new_lines = []

            for line in lines:
                stripped = line.strip()

                # Keep comments and empty lines as-is
                if not stripped or stripped.startswith('#'):
                    new_lines.append(line)
                    continue

                # Check if this line has a key we want to update
                if '=' in stripped:
                    key = stripped.split('=', 1)[0].strip()

                    if key in updates:
                        # Update this key
                        new_lines.append(f"{key}={updates[key]}\n")
                        updated_keys.add(key)
                    else:
                        # Keep line as-is
                        new_lines.append(line)
                else:
                    new_lines.append(line)

            # Add any new keys that weren't in the file
            for key, value in updates.items():
                if key not in updated_keys:
                    new_lines.append(f"{key}={value}\n")

            # Write back to file
            with open(env_path, 'w') as f:
                f.writelines(new_lines)

            return True

        except Exception as e:
            print(f"Error updating .env file: {e}")
            return False

    @staticmethod
    def get_env_value(key: str, default: Optional[str] = None) -> Optional[str]:
        """Get a specific value from .env file"""
        env_vars = EnvManager.read_env_file()
        return env_vars.get(key, default)

    @staticmethod
    def validate_env_file() -> tuple[bool, list[str]]:
        """
        Validate that required environment variables exist

        Returns:
            (is_valid: bool, missing_keys: list[str])
        """
        required_keys = [
            'LLM_BASE_URL',
            'LLM_MODEL',
            'LLM_API_KEY',
            'EMBEDDING_BASE_URL',
            'EMBEDDING_MODEL',
            'EMBEDDING_API_KEY'
        ]

        env_vars = EnvManager.read_env_file()
        missing = [key for key in required_keys if key not in env_vars or not env_vars[key]]

        return len(missing) == 0, missing
