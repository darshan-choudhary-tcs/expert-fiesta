"""
Authentication Utilities
Handles password hashing, JWT token generation, and user authentication
"""

import bcrypt
from datetime import datetime, timedelta
from typing import Optional, Dict
from jose import JWTError, jwt
from config.settings import settings
from models.user import User, get_session

# Role definitions
ROLES = {"admin", "editor", "user"}


def is_valid_role(role: str) -> bool:
    return role in ROLES


class AuthService:
    """Service for handling authentication operations"""

    @staticmethod
    def hash_password(password: str) -> str:
        """Hash a password using bcrypt"""
        salt = bcrypt.gensalt()
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')

    @staticmethod
    def verify_password(plain_password: str, hashed_password: str) -> bool:
        """Verify a password against its hash"""
        try:
            return bcrypt.checkpw(
                plain_password.encode('utf-8'),
                hashed_password.encode('utf-8')
            )
        except Exception as e:
            print(f"Password verification error: {e}")
            return False

    @staticmethod
    def create_access_token(user_id: int, username: str, role: str = 'user', is_admin: bool = False) -> str:
        """Create a JWT access token"""
        expire = datetime.utcnow() + timedelta(hours=settings.jwt_expiration_hours)

        payload = {
            'user_id': user_id,
            'username': username,
            'is_admin': is_admin,
            'role': role,
            'exp': expire,
            'iat': datetime.utcnow()
        }

        token = jwt.encode(
            payload,
            settings.jwt_secret_key,
            algorithm=settings.jwt_algorithm
        )
        return token

    @staticmethod
    def decode_token(token: str) -> Optional[Dict]:
        """Decode and validate a JWT token"""
        try:
            payload = jwt.decode(
                token,
                settings.jwt_secret_key,
                algorithms=[settings.jwt_algorithm]
            )
            return payload
        except JWTError as e:
            print(f"Token decode error: {e}")
            return None

    @staticmethod
    def authenticate_user(username: str, password: str) -> Optional[Dict]:
        """Authenticate a user with username and password"""
        session = get_session()
        try:
            # Find user by username or email
            user = session.query(User).filter(
                (User.username == username) | (User.email == username)
            ).first()

            if not user:
                return None

            if not user.is_active:
                return None

            # Verify password
            if not AuthService.verify_password(password, user.password_hash):
                return None

            # Update last login
            user.last_login = datetime.utcnow()
            session.commit()

            # Convert to dict before closing session
            user_dict = user.to_dict()
            return user_dict

        except Exception as e:
            print(f"Authentication error: {e}")
            session.rollback()
            return None
        finally:
            session.close()

    @staticmethod
    def register_user(username: str, email: str, password: str, full_name: str = None, role: str = 'user') -> tuple[bool, str, Optional[Dict]]:
        """
        Register a new user
        Returns: (success: bool, message: str, user_dict: Optional[Dict])
        """
        session = get_session()
        try:
            if not is_valid_role(role):
                role = 'user'
            # Check if username exists
            existing_user = session.query(User).filter(User.username == username).first()
            if existing_user:
                return False, "Username already exists", None

            # Check if email exists
            existing_email = session.query(User).filter(User.email == email).first()
            if existing_email:
                return False, "Email already exists", None

            # Create new user
            hashed_password = AuthService.hash_password(password)
            new_user = User(
                username=username,
                email=email,
                password_hash=hashed_password,
                full_name=full_name,
                is_active=True,
                is_admin=True if role == 'admin' else False,
                role=role
            )

            session.add(new_user)
            session.commit()
            session.refresh(new_user)

            # Convert to dict before closing session
            user_dict = new_user.to_dict()
            return True, "User registered successfully", user_dict

        except Exception as e:
            session.rollback()
            print(f"Registration error: {e}")
            return False, f"Registration failed: {str(e)}", None
        finally:
            session.close()

    @staticmethod
    def get_user_by_id(user_id: int) -> Optional[Dict]:
        """Get user by ID"""
        session = get_session()
        try:
            user = session.query(User).filter(User.id == user_id).first()
            if user:
                # Convert to dict before closing session
                return user.to_dict()
            return None
        except Exception as e:
            print(f"Error fetching user: {e}")
            return None
        finally:
            session.close()

    @staticmethod
    def update_user_role(user_id: int, role: str) -> tuple[bool, str]:
        """Update a user's role"""
        if not is_valid_role(role):
            return False, "Invalid role"
        session = get_session()
        try:
            user = session.query(User).filter(User.id == user_id).first()
            if not user:
                return False, "User not found"
            user.role = role
            user.is_admin = True if role == 'admin' else False  # keep legacy flag in sync
            session.commit()
            return True, "Role updated"
        except Exception as e:
            session.rollback()
            print(f"Role update error: {e}")
            return False, f"Role update failed: {str(e)}"
        finally:
            session.close()

    @staticmethod
    def update_user_profile(user_id: int, full_name: str = None, email: str = None) -> tuple[bool, str]:
        """Update user profile"""
        session = get_session()
        try:
            user = session.query(User).filter(User.id == user_id).first()
            if not user:
                return False, "User not found"

            if full_name:
                user.full_name = full_name

            if email:
                # Check if email is already taken by another user
                existing = session.query(User).filter(
                    User.email == email,
                    User.id != user_id
                ).first()
                if existing:
                    return False, "Email already in use"
                user.email = email

            session.commit()
            return True, "Profile updated successfully"

        except Exception as e:
            session.rollback()
            print(f"Profile update error: {e}")
            return False, f"Update failed: {str(e)}"
        finally:
            session.close()

    @staticmethod
    def change_password(user_id: int, old_password: str, new_password: str) -> tuple[bool, str]:
        """Change user password"""
        session = get_session()
        try:
            user = session.query(User).filter(User.id == user_id).first()
            if not user:
                return False, "User not found"

            # Verify old password
            if not AuthService.verify_password(old_password, user.password_hash):
                return False, "Current password is incorrect"

            # Update password
            user.password_hash = AuthService.hash_password(new_password)
            session.commit()
            return True, "Password changed successfully"

        except Exception as e:
            session.rollback()
            print(f"Password change error: {e}")
            return False, f"Password change failed: {str(e)}"
        finally:
            session.close()
