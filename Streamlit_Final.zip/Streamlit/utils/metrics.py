"""
Metrics Tracking Utilities
Track and record performance metrics
"""

import time
from datetime import datetime
from contextlib import contextmanager
from typing import Optional, Dict, Any
from models.metrics import PerformanceMetric, SystemStats
from models.user import get_session
from utils.logger import log_error


class MetricsTracker:
    """Utility class for tracking performance metrics"""

    @staticmethod
    def record_metric(
        metric_type: str,
        user_id: Optional[int] = None,
        session_id: Optional[str] = None,
        operation: Optional[str] = None,
        latency_ms: Optional[float] = None,
        tokens_used: Optional[int] = None,
        tokens_prompt: Optional[int] = None,
        tokens_completion: Optional[int] = None,
        num_documents_retrieved: Optional[int] = None,
        avg_relevance_score: Optional[float] = None,
        cache_hit: bool = False,
        agent_name: Optional[str] = None,
        num_agent_steps: Optional[int] = None,
        agent_success: Optional[bool] = None,
        error_message: Optional[str] = None,
        meta_data_str: Optional[str] = None
    ) -> bool:
        """
        Record a performance metric to the database

        Args:
            metric_type: Type of metric (e.g., 'query', 'embedding', 'agent')
            user_id: User ID
            session_id: Session ID
            operation: Specific operation name
            latency_ms: Latency in milliseconds
            tokens_used: Total tokens used
            tokens_prompt: Tokens in prompt
            tokens_completion: Tokens in completion
            num_documents_retrieved: Number of documents retrieved
            avg_relevance_score: Average relevance score
            cache_hit: Whether result was from cache
            agent_name: Name of agent
            num_agent_steps: Number of agent steps
            agent_success: Whether agent succeeded
            error_message: Error message if any
            metadata: Additional metadata as JSON string

        Returns:
            Success status
        """
        session = get_session()
        try:
            metric = PerformanceMetric(
                user_id=user_id,
                session_id=session_id,
                metric_type=metric_type,
                operation=operation,
                latency_ms=latency_ms,
                tokens_used=tokens_used,
                tokens_prompt=tokens_prompt,
                tokens_completion=tokens_completion,
                num_documents_retrieved=num_documents_retrieved,
                avg_relevance_score=avg_relevance_score,
                cache_hit=cache_hit,
                agent_name=agent_name,
                num_agent_steps=num_agent_steps,
                agent_success=agent_success,
                error_message=error_message,
                meta_data=meta_data_str
            )

            session.add(metric)
            session.commit()
            return True

        except Exception as e:
            session.rollback()
            log_error(f"Error recording metric: {e}", exc_info=True)
            return False
        finally:
            session.close()

    @staticmethod
    @contextmanager
    def track_latency(
        metric_type: str,
        operation: str,
        user_id: Optional[int] = None,
        session_id: Optional[str] = None,
        **kwargs
    ):
        """
        Context manager to track latency of an operation

        Usage:
            with MetricsTracker.track_latency('query', 'rag_search', user_id=1):
                # Your code here
                pass
        """
        start_time = time.time()
        error_msg = None
        success = True

        try:
            yield
        except Exception as e:
            error_msg = str(e)
            success = False
            raise
        finally:
            latency_ms = (time.time() - start_time) * 1000

            # Record the metric
            MetricsTracker.record_metric(
                metric_type=metric_type,
                operation=operation,
                user_id=user_id,
                session_id=session_id,
                latency_ms=latency_ms,
                agent_success=success,
                error_message=error_msg,
                **kwargs
            )

    @staticmethod
    def get_user_metrics(user_id: int, limit: int = 100) -> list:
        """Get recent metrics for a user"""
        session = get_session()
        try:
            metrics = session.query(PerformanceMetric)\
                .filter(PerformanceMetric.user_id == user_id)\
                .order_by(PerformanceMetric.timestamp.desc())\
                .limit(limit)\
                .all()
            return [m.to_dict() for m in metrics]
        except Exception as e:
            log_error(f"Error fetching user metrics: {e}")
            return []
        finally:
            session.close()

    @staticmethod
    def get_system_metrics(days: int = 7) -> Dict[str, Any]:
        """Get aggregated system metrics for the last N days"""
        session = get_session()
        try:
            from datetime import timedelta
            from sqlalchemy import func

            start_date = datetime.utcnow() - timedelta(days=days)

            # Query aggregated metrics
            result = session.query(
                func.count(PerformanceMetric.id).label('total_queries'),
                func.avg(PerformanceMetric.latency_ms).label('avg_latency'),
                func.sum(PerformanceMetric.tokens_used).label('total_tokens'),
                func.avg(PerformanceMetric.avg_relevance_score).label('avg_relevance'),
                func.sum(PerformanceMetric.cache_hit.cast(int)).label('cache_hits'),
                func.count(PerformanceMetric.error_message).label('error_count')
            ).filter(
                PerformanceMetric.timestamp >= start_date
            ).first()

            total = result.total_queries or 0
            cache_hit_rate = (result.cache_hits / total * 100) if total > 0 else 0
            error_rate = (result.error_count / total * 100) if total > 0 else 0

            return {
                'total_queries': total,
                'avg_latency_ms': round(result.avg_latency, 2) if result.avg_latency else 0,
                'total_tokens_used': result.total_tokens or 0,
                'avg_relevance_score': round(result.avg_relevance, 3) if result.avg_relevance else 0,
                'cache_hit_rate': round(cache_hit_rate, 2),
                'error_rate': round(error_rate, 2),
                'period_days': days
            }

        except Exception as e:
            log_error(f"Error fetching system metrics: {e}")
            return {}
        finally:
            session.close()

    @staticmethod
    def get_agent_performance(agent_name: Optional[str] = None, days: int = 7) -> list:
        """Get agent performance metrics"""
        session = get_session()
        try:
            from datetime import timedelta
            from sqlalchemy import func

            start_date = datetime.utcnow() - timedelta(days=days)

            query = session.query(
                PerformanceMetric.agent_name,
                func.count(PerformanceMetric.id).label('executions'),
                func.avg(PerformanceMetric.latency_ms).label('avg_latency'),
                func.avg(PerformanceMetric.num_agent_steps).label('avg_steps'),
                func.sum(PerformanceMetric.agent_success.cast(int)).label('successes')
            ).filter(
                PerformanceMetric.metric_type == 'agent',
                PerformanceMetric.timestamp >= start_date
            )

            if agent_name:
                query = query.filter(PerformanceMetric.agent_name == agent_name)

            results = query.group_by(PerformanceMetric.agent_name).all()

            metrics = []
            for r in results:
                success_rate = (r.successes / r.executions * 100) if r.executions > 0 else 0
                metrics.append({
                    'agent_name': r.agent_name,
                    'executions': r.executions,
                    'avg_latency_ms': round(r.avg_latency, 2) if r.avg_latency else 0,
                    'avg_steps': round(r.avg_steps, 1) if r.avg_steps else 0,
                    'success_rate': round(success_rate, 2)
                })

            return metrics

        except Exception as e:
            log_error(f"Error fetching agent metrics: {e}")
            return []
        finally:
            session.close()
