"""
Utility functions for Ollama management and health checks
"""
import httpx
from typing import Dict, List, Optional, Tuple
from utils.logger import log_info, log_error


def check_ollama_connection(base_url: str = "http://localhost:11434") -> Tuple[bool, str]:
    """
    Check if Ollama server is running and accessible

    Args:
        base_url: Ollama base URL

    Returns:
        Tuple of (is_connected, message)
    """
    try:
        response = httpx.get(f"{base_url}/api/version", timeout=5.0)
        if response.status_code == 200:
            version_data = response.json()
            version = version_data.get('version', 'unknown')
            return True, f"Connected (v{version})"
        else:
            return False, f"Server returned status {response.status_code}"
    except httpx.ConnectError:
        return False, "Connection refused. Is Ollama running? Try: ollama serve"
    except httpx.TimeoutException:
        return False, "Connection timeout. Check if Ollama is responsive"
    except Exception as e:
        return False, f"Error: {str(e)}"


def list_ollama_models(base_url: str = "http://localhost:11434") -> Tuple[bool, List[Dict]]:
    """
    Get list of installed Ollama models

    Args:
        base_url: Ollama base URL

    Returns:
        Tuple of (success, models_list)
    """
    try:
        response = httpx.get(f"{base_url}/api/tags", timeout=10.0)
        if response.status_code == 200:
            data = response.json()
            models = data.get('models', [])
            return True, models
        else:
            log_error(f"Failed to list models: {response.status_code}")
            return False, []
    except Exception as e:
        log_error(f"Error listing Ollama models: {e}")
        return False, []


def get_model_info(model_name: str, base_url: str = "http://localhost:11434") -> Optional[Dict]:
    """
    Get information about a specific Ollama model

    Args:
        model_name: Name of the model
        base_url: Ollama base URL

    Returns:
        Model information dictionary or None
    """
    try:
        response = httpx.post(
            f"{base_url}/api/show",
            json={"name": model_name},
            timeout=10.0
        )
        if response.status_code == 200:
            return response.json()
        else:
            return None
    except Exception as e:
        log_error(f"Error getting model info for {model_name}: {e}")
        return None


def pull_ollama_model(model_name: str, base_url: str = "http://localhost:11434") -> Tuple[bool, str]:
    """
    Pull/download an Ollama model

    Args:
        model_name: Name of the model to pull
        base_url: Ollama base URL

    Returns:
        Tuple of (success, message)
    """
    try:
        # This is a streaming endpoint, we'll just initiate the pull
        response = httpx.post(
            f"{base_url}/api/pull",
            json={"name": model_name},
            timeout=300.0  # 5 minutes timeout for model download
        )
        if response.status_code == 200:
            return True, f"Model '{model_name}' pull initiated successfully"
        else:
            return False, f"Failed to pull model: {response.status_code}"
    except Exception as e:
        return False, f"Error pulling model: {str(e)}"


def test_ollama_llm(
    model_name: str,
    base_url: str = "http://localhost:11434",
    prompt: str = "Hello, how are you?"
) -> Tuple[bool, str]:
    """
    Test if an LLM model is working

    Args:
        model_name: Name of the model to test
        base_url: Ollama base URL
        prompt: Test prompt

    Returns:
        Tuple of (success, response_or_error)
    """
    try:
        response = httpx.post(
            f"{base_url}/api/generate",
            json={
                "model": model_name,
                "prompt": prompt,
                "stream": False
            },
            timeout=30.0
        )
        if response.status_code == 200:
            data = response.json()
            return True, data.get('response', 'No response')
        else:
            return False, f"Model test failed: {response.status_code}"
    except Exception as e:
        return False, f"Error testing model: {str(e)}"


def test_ollama_embeddings(
    model_name: str,
    base_url: str = "http://localhost:11434",
    text: str = "test embedding"
) -> Tuple[bool, str]:
    """
    Test if an embedding model is working

    Args:
        model_name: Name of the embedding model to test
        base_url: Ollama base URL
        text: Test text

    Returns:
        Tuple of (success, message)
    """
    try:
        response = httpx.post(
            f"{base_url}/api/embeddings",
            json={
                "model": model_name,
                "prompt": text
            },
            timeout=30.0
        )
        if response.status_code == 200:
            data = response.json()
            embedding = data.get('embedding', [])
            if embedding:
                return True, f"Embedding generated successfully ({len(embedding)} dimensions)"
            else:
                return False, "No embedding returned"
        else:
            return False, f"Embedding test failed: {response.status_code}"
    except Exception as e:
        return False, f"Error testing embeddings: {str(e)}"


def get_recommended_models() -> Dict[str, List[str]]:
    """
    Get recommended Ollama models for different use cases

    Returns:
        Dictionary with model recommendations
    """
    return {
        "llm": [
            "llama3.2",
            "llama3.1",
            "mistral",
            "phi3",
            "gemma2",
            "codellama",
            "qwen2.5"
        ],
        "embeddings": [
            "nomic-embed-text",
            "mxbai-embed-large",
            "all-minilm",
            "snowflake-arctic-embed"
        ]
    }


def format_model_size(size_bytes: int) -> str:
    """
    Format model size in human-readable format

    Args:
        size_bytes: Size in bytes

    Returns:
        Formatted size string
    """
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    size = float(size_bytes)
    unit_index = 0

    while size >= 1024 and unit_index < len(units) - 1:
        size /= 1024
        unit_index += 1

    return f"{size:.2f} {units[unit_index]}"
