# Quick Start Guide

## 🚀 Getting Started

### 1. Installation

```bash
# Navigate to project directory
cd "/private/var/www/GenAI/AI Friday/Streamlit"

# Install dependencies
pip install -r requirements.txt
```

### 2. Configuration

```bash
# Copy environment template
cp .env.example .env

# Edit .env file with your API keys
nano .env
```

**Required Configuration:**
- `LLM_API_KEY`: Your API key
- `EMBEDDING_API_KEY`: Your embedding model API key
- `JWT_SECRET_KEY`: Change this for production!

### 3. Initialize Database & Setup

```bash
# Run setup script
python setup.py
```

This will:
- Create database tables
- Create admin user (username: `admin`, password: `Admin123!`)
- Test LLM and embedding connections
- Create sample documents

### 4. Run Application

```bash
streamlit run main.py
```

The app will open in your browser at `http://localhost:8501`

---

## 📁 Project Structure

```
.
├── app/pages/              # Streamlit pages
│   ├── login.py           # Login page
│   ├── register.py        # Registration page
│   ├── dashboard.py       # Main chat interface
│   ├── rag_uploader.py # Document upload/management
│   ├── explainability_dashboard.py # AI insights
│   └── admin.py           # Admin panel
│
├── config/                 # Configuration
│   ├── settings.py        # Settings loader
│   └── prompts.py         # Prompt templates
│
├── core/                   # Core functionality
│   ├── llm/               # LLM & embeddings
│   │   ├── llm_config.py
│   │   ├── embeddings.py
│   │   └── prompts.py
│   └── agents/            # Multi-agent system
│       ├── agent_graph.py
│       ├── agent_nodes.py
│       └── agent_tools.py
│
├── models/                 # Database models
│   ├── user.py            # User & conversation models
│   ├── document.py        # Document model
│   └── metrics.py         # Performance metrics
│
├── services/               # Business logic
│   ├── vector_store.py    # ChromaDB operations
│   ├── document_processor.py # Document processing
│   ├── rag_service.py     # RAG pipeline
│   ├── grounding.py       # Grounding & citations
│   ├── explainability.py  # Explainability service
│   ├── conversation_service.py # Conversation history
│   └── cache_service.py   # Response caching
│
├── utils/                  # Utilities
│   ├── auth.py            # Authentication
│   ├── session.py         # Session management
│   ├── validators.py      # Input validation
│   ├── logger.py          # Logging
│   └── metrics.py         # Metrics tracking
│
├── static/                 # Static files
│   └── custom.css         # Custom styling
│
├── tests/                  # Unit tests
│   └── test_basic.py
│
├── main.py                 # Application entry point
├── setup.py                # Setup script
├── requirements.txt        # Dependencies
├── .env.example            # Environment template
└── README.md               # Documentation
```

---

## 🎯 Features Overview

### 1. **RAG (Retrieval-Augmented Generation)**
- Document upload (PDF, TXT, DOCX)
- Intelligent chunking with overlap
- Vector similarity search
- MMR (Maximal Marginal Relevance) for diverse results
- Source attribution and citations

### 2. **Multi-Agent System**
- **Router Agent**: Analyzes query intent
- **Researcher Agent**: Gathers information
- **Analyzer Agent**: Performs analysis
- **Synthesizer Agent**: Generates final response
- **Reflection Agent**: Quality assurance

### 3. **Explainability**
- Source document attribution
- Confidence scoring
- Chain-of-thought reasoning
- Agent execution traces
- Relevance visualization

### 4. **Grounding**
- Citation generation with page numbers
- Fact-checking against sources
- Hallucination detection
- Confidence metrics

### 5. **Performance Monitoring**
- Query latency tracking
- Token usage statistics
- Cache hit rates
- Agent performance metrics

### 6. **User Management**
- Secure authentication (JWT + bcrypt)
- Role-based access control
- Conversation history
- Document management per user

---

## Usage Examples

### Basic RAG Query
1. Login to dashboard
2. Select "RAG (Document Search)" mode
3. Upload documents in RAG Uploader
4. Ask questions in dashboard
5. View sources and explanations

### Multi-Agent Query
1. Select "Multi-Agent System" mode
2. Ask complex questions requiring reasoning
3. View agent execution flow in Explainability Dashboard

### Document Management
1. Go to RAG Uploader
2. Upload PDF/TXT/DOCX files
3. Documents are automatically processed and embedded
4. View uploaded documents and collections

### PII Scrubbing
1. Go to PII Scrubber page
2. Enter or paste text containing PII
3. Choose replacement type (placeholder, hash, or fake)
4. Click "Scrub PII" to detect and remove sensitive information
5. Download scrubbed text or process batch files

### Admin Panel
1. Login as admin user
2. View system metrics and performance
3. Manage users and documents
4. **Configure system settings** (LLM, embeddings, API keys)
5. Clear cache and perform maintenance

### System Settings (Admin Only)
1. Go to Admin Panel → Settings tab
2. Update LLM configuration (URL, model, API key, max tokens)
3. Update embedding configuration (URL, model, API key)
4. Adjust temperature for response randomness
5. Click "Save Settings" to update .env file
6. Restart application for changes to take full effect

---

## Customization

### Add New Agent
Edit `core/agents/agent_nodes.py`:

```python
def custom_agent(state: AgentState) -> AgentState:
    # Your agent logic here
    return state
```

Add to graph in `core/agents/agent_graph.py`

### Add New Tool
Edit `core/agents/agent_tools.py`:

```python
@tool
def my_tool(input: str) -> str:
    """Tool description"""
    # Your tool logic
    return result
```

### Customize Prompts
Edit `core/llm/prompts.py` to modify system prompts

### Add New Page
Create new file in `app/pages/` and add routing in `main.py`

---

## 🧪 Testing

```bash
# Run tests
pytest tests/ -v

# Run specific test
pytest tests/test_basic.py::test_password_validation -v
```

---

## Performance Tips

1. **Enable Caching**: Set `CACHE_ENABLED=true` in `.env`
2. **Adjust Chunk Size**: Modify `CHUNK_SIZE` and `CHUNK_OVERLAP` for your use case
3. **Optimize Vector Search**: Use MMR for diverse results
4. **Monitor Metrics**: Check admin panel regularly

---

## Security Notes

- Change `JWT_SECRET_KEY` before production
- Use strong passwords (enforced by validators)
- API keys stored in `.env` (not committed)
- SSL verification disabled for GenAI Lab (httpx client)

---

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `LLM_BASE_URL` | LLM endpoint URL | https://xxx.xxx.in |
| `LLM_MODEL` | Model name | azure_ai/genailab-maas-DeepSeek-V3-0324 |
| `LLM_API_KEY` | API key for LLM | *required* |
| `EMBEDDING_MODEL` | Embedding model | azure/genailab-maas-text-embedding-3-large |
| `EMBEDDING_API_KEY` | API key for embeddings | *required* |
| `CHUNK_SIZE` | Document chunk size | 1000 |
| `CHUNK_OVERLAP` | Chunk overlap | 200 |
| `CACHE_ENABLED` | Enable response caching | true |
| `MAX_TOKENS` | Max tokens per response | 4000 |
| `TEMPERATURE` | LLM temperature | 0.7 |

---

## 🐛 Troubleshooting

### Database Issues
```bash
# Reinitialize database
python setup.py
```

### LLM Connection Failed
- Check `LLM_API_KEY` in `.env`
- Verify network connectivity
- Check API endpoint URL

### Embeddings Not Working
- Verify `EMBEDDING_API_KEY`
- Check model name in `.env`

### Import Errors
```bash
# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

---

## 📚 Additional Resources

- **LangChain Docs**: https://python.langchain.com/docs/
- **LangGraph Docs**: https://langchain-ai.github.io/langgraph/
- **ChromaDB Docs**: https://docs.trychroma.com/
- **Streamlit Docs**: https://docs.streamlit.io/

---

## 🤝 Support

For issues or questions:
1. Check inline code comments
2. Review README.md and QUICKSTART.md
3. Check logs in `logs/app.log`

---

## License

This boilerplate is provided for hackathon use. Modify as needed for your project.
