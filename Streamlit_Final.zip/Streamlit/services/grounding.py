"""
Grounding Service
Provides citation, confidence scoring, and fact-checking capabilities
"""

from typing import List, Dict, Any, Optional
from core.llm.llm_config import get_llm
from core.llm.prompts import get_grounding_verification_prompt, get_fact_check_prompt
from utils.logger import log_info, log_error
import json
import re


class GroundingService:
    """Service for grounding and verification"""

    def __init__(self):
        self.llm = get_llm(temperature=0.0)  # Use low temperature for factual tasks

    def generate_citations(self, answer: str, sources: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generate citations for answer based on sources

        Returns:
            Dict with annotated answer and citation list
        """
        try:
            citations = []
            for i, source in enumerate(sources, 1):
                citation = {
                    'id': i,
                    'filename': source.get('metadata', {}).get('filename', 'Unknown'),
                    'chunk_index': source.get('metadata', {}).get('chunk_index', '?'),
                    'relevance_score': source.get('score', 0.0),
                    'snippet': source.get('document', '')[:200] + '...'
                }
                citations.append(citation)

            log_info(f"Generated {len(citations)} citations")

            return {
                'answer': answer,
                'citations': citations,
                'num_citations': len(citations)
            }

        except Exception as e:
            log_error(f"Error generating citations: {e}")
            return {'answer': answer, 'citations': [], 'num_citations': 0}

    def calculate_confidence(
        self,
        answer: str,
        sources: List[Dict[str, Any]],
        query: str
    ) -> float:
        """
        Calculate confidence score for answer

        Returns:
            Confidence score (0.0 to 1.0)
        """
        try:
            if not sources:
                return 0.0

            # Factors for confidence
            avg_relevance = sum(s.get('score', 0) for s in sources) / len(sources)
            num_sources_factor = min(len(sources) / 5, 1.0)  # Normalize to 5 sources
            answer_length_factor = min(len(answer.split()) / 50, 1.0)  # Reasonable length

            # Weighted confidence
            confidence = (
                avg_relevance * 0.6 +
                num_sources_factor * 0.2 +
                answer_length_factor * 0.2
            )

            return round(confidence, 3)

        except Exception as e:
            log_error(f"Error calculating confidence: {e}")
            return 0.5

    def verify_grounding(self, statement: str, sources: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Verify if statement is grounded in sources

        Returns:
            Verification result with score and explanation
        """
        try:
            sources_text = "\n\n".join([s.get('document', '') for s in sources[:3]])

            prompt = get_grounding_verification_prompt()
            verification_text = prompt.format(statement=statement, sources=sources_text)

            response = self.llm.invoke(verification_text)
            result_text = response.content

            # Parse response
            grounded = "YES" in result_text.upper()

            # Extract confidence if present
            confidence_match = re.search(r'CONFIDENCE:\s*([\d.]+)', result_text)
            confidence = float(confidence_match.group(1)) if confidence_match else 0.5

            return {
                'grounded': grounded,
                'confidence': confidence,
                'explanation': result_text
            }

        except Exception as e:
            log_error(f"Error verifying grounding: {e}")
            return {'grounded': False, 'confidence': 0.0, 'explanation': str(e)}

    def fact_check(self, claim: str, context: str) -> Dict[str, Any]:
        """
        Fact-check a claim against context

        Returns:
            Fact-check result
        """
        try:
            prompt = get_fact_check_prompt()
            check_text = prompt.format(claim=claim, context=context)

            response = self.llm.invoke(check_text)
            result_text = response.content

            # Try to parse JSON response
            try:
                result = json.loads(result_text)
            except json.JSONDecodeError:
                # Fallback parsing
                result = {
                    'supported': 'true' in result_text.lower() or 'supported' in result_text.lower(),
                    'confidence': 0.5,
                    'evidence': [],
                    'explanation': result_text
                }

            return result

        except Exception as e:
            log_error(f"Error in fact checking: {e}")
            return {
                'supported': False,
                'confidence': 0.0,
                'evidence': [],
                'explanation': str(e)
            }

    def detect_hallucination(
        self,
        answer: str,
        sources: List[Dict[str, Any]],
        threshold: float = 0.7
    ) -> Dict[str, Any]:
        """
        Detect potential hallucinations in answer

        Returns:
            Hallucination detection result
        """
        try:
            # Extract key claims from answer
            sentences = [s.strip() for s in answer.split('.') if s.strip()]

            hallucination_risks = []

            for sentence in sentences[:5]:  # Check first 5 sentences
                if len(sentence.split()) < 5:  # Skip short sentences
                    continue

                verification = self.verify_grounding(sentence, sources)

                if verification['confidence'] < threshold:
                    hallucination_risks.append({
                        'sentence': sentence,
                        'confidence': verification['confidence'],
                        'risk': 'high' if verification['confidence'] < 0.5 else 'medium'
                    })

            has_hallucination = len(hallucination_risks) > 0

            return {
                'has_hallucination': has_hallucination,
                'risks': hallucination_risks,
                'overall_confidence': 1.0 - (len(hallucination_risks) / max(len(sentences), 1))
            }

        except Exception as e:
            log_error(f"Error detecting hallucination: {e}")
            return {'has_hallucination': False, 'risks': [], 'overall_confidence': 0.5}
