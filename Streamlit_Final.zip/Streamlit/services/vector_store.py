"""
Vector Store Service
Manages ChromaDB vector store for document embeddings and retrieval
"""

import chromadb
from chromadb.config import Settings
from typing import List, Dict, Optional, Any
import uuid
from config.settings import settings
from core.llm.embeddings import get_embeddings, embed_texts, embed_query
from utils.logger import log_info, log_error


# Global ChromaDB client instance (singleton pattern)
_chroma_client = None


def get_chroma_client() -> chromadb.Client:
    """Get or create singleton ChromaDB client"""
    global _chroma_client

    if _chroma_client is None:
        try:
            chroma_path = settings.get_chroma_path()
            _chroma_client = chromadb.PersistentClient(
                path=str(chroma_path),
                settings=Settings(
                    anonymized_telemetry=False,
                    allow_reset=True
                )
            )
            log_info(f"ChromaDB client initialized at {chroma_path}")
        except Exception as e:
            log_error(f"Error initializing ChromaDB client: {e}", exc_info=True)
            raise

    return _chroma_client


class VectorStoreService:
    """Service for managing vector store operations"""

    def __init__(self, collection_name: str = "default"):
        """
        Initialize vector store service

        Args:
            collection_name: Name of the collection to use
        """
        self.collection_name = collection_name
        self.embeddings = get_embeddings()
        self.client = get_chroma_client()
        self.collection = self._get_or_create_collection()

    def _get_or_create_collection(self):
        """Get or create a collection"""
        try:
            collection = self.client.get_or_create_collection(
                name=self.collection_name,
                metadata={"description": f"Collection for {self.collection_name}"}
            )
            log_info(f"Collection '{self.collection_name}' ready")
            return collection
        except Exception as e:
            log_error(f"Error creating collection: {e}", exc_info=True)
            raise

    def add_documents(
        self,
        texts: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        ids: Optional[List[str]] = None
    ) -> List[str]:
        """
        Add documents to the vector store

        Args:
            texts: List of text chunks to add
            metadatas: Optional metadata for each chunk
            ids: Optional IDs for each chunk (generated if not provided)

        Returns:
            List of document IDs
        """
        try:
            # Generate IDs if not provided
            if ids is None:
                ids = [str(uuid.uuid4()) for _ in texts]

            # Generate embeddings
            log_info(f"Generating embeddings for {len(texts)} documents...")
            # Use retry-safe wrapper for batch embeddings
            embeddings_list = embed_texts(texts)

            # Prepare metadatas
            if metadatas is None:
                metadatas = [{} for _ in texts]

            # Add to collection
            self.collection.add(
                ids=ids,
                embeddings=embeddings_list,
                documents=texts,
                metadatas=metadatas
            )

            log_info(f"Added {len(texts)} documents to collection '{self.collection_name}'")
            return ids

        except Exception as e:
            log_error(f"Error adding documents: {e}", exc_info=True)
            raise

    def similarity_search(
        self,
        query: str,
        k: int = 5,
        filter: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Search for similar documents

        Args:
            query: Query string
            k: Number of results to return
            filter: Optional metadata filter

        Returns:
            List of results with documents, metadata, and scores
        """
        try:
            # Generate query embedding
            # Use retry-safe wrapper for query embedding
            query_embedding = embed_query(query)

            # Search
            results = self.collection.query(
                query_embeddings=[query_embedding],
                n_results=k,
                where=filter
            )

            # Format results
            formatted_results = []
            if results['documents'] and len(results['documents']) > 0:
                for i in range(len(results['documents'][0])):
                    formatted_results.append({
                        'id': results['ids'][0][i],
                        'document': results['documents'][0][i],
                        'metadata': results['metadatas'][0][i] if results['metadatas'] else {},
                        'score': 1 - results['distances'][0][i]  # Convert distance to similarity
                    })

            log_info(f"Found {len(formatted_results)} similar documents")
            return formatted_results

        except Exception as e:
            log_error(f"Error in similarity search: {e}", exc_info=True)
            return []

    def mmr_search(
        self,
        query: str,
        k: int = 5,
        fetch_k: int = 20,
        lambda_mult: float = 0.5,
        filter: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        Maximal Marginal Relevance search for diverse results

        Args:
            query: Query string
            k: Number of results to return
            fetch_k: Number of initial results to fetch
            lambda_mult: Diversity parameter (0=max diversity, 1=max relevance)
            filter: Optional metadata filter

        Returns:
            List of diverse results
        """
        try:
            # Get initial results
            initial_results = self.similarity_search(query, k=fetch_k, filter=filter)

            if len(initial_results) <= k:
                return initial_results

            # Simple MMR implementation
            selected = []
            remaining = initial_results.copy()

            # Select first (most relevant) document
            selected.append(remaining.pop(0))

            while len(selected) < k and remaining:
                # Calculate MMR scores
                best_idx = 0
                best_score = -float('inf')

                for idx, candidate in enumerate(remaining):
                    # Relevance score
                    relevance = candidate['score']

                    # Diversity score (inverse of max similarity to selected)
                    max_sim = max(
                        self._text_similarity(candidate['document'], sel['document'])
                        for sel in selected
                    )
                    diversity = 1 - max_sim

                    # MMR score
                    mmr_score = lambda_mult * relevance + (1 - lambda_mult) * diversity

                    if mmr_score > best_score:
                        best_score = mmr_score
                        best_idx = idx

                selected.append(remaining.pop(best_idx))

            log_info(f"MMR search returned {len(selected)} diverse documents")
            return selected

        except Exception as e:
            log_error(f"Error in MMR search: {e}", exc_info=True)
            return self.similarity_search(query, k, filter)  # Fallback

    def _text_similarity(self, text1: str, text2: str) -> float:
        """Simple Jaccard similarity between texts"""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        intersection = words1.intersection(words2)
        union = words1.union(words2)
        return len(intersection) / len(union) if union else 0.0

    def delete_documents(self, ids: List[str]) -> bool:
        """Delete documents by IDs"""
        try:
            self.collection.delete(ids=ids)
            log_info(f"Deleted {len(ids)} documents")
            return True
        except Exception as e:
            log_error(f"Error deleting documents: {e}", exc_info=True)
            return False

    def get_collection_count(self) -> int:
        """Get number of documents in collection"""
        try:
            return self.collection.count()
        except Exception as e:
            log_error(f"Error getting collection count: {e}")
            return 0

    def delete_collection(self) -> bool:
        """Delete the entire collection"""
        try:
            self.client.delete_collection(self.collection_name)
            log_info(f"Deleted collection '{self.collection_name}'")
            return True
        except Exception as e:
            log_error(f"Error deleting collection: {e}", exc_info=True)
            return False

    @staticmethod
    def list_collections() -> List[str]:
        """List all available collections"""
        try:
            client = get_chroma_client()
            collections = client.list_collections()
            return [c.name for c in collections]
        except Exception as e:
            log_error(f"Error listing collections: {e}")
            return []

    @staticmethod
    def reset_client():
        """Reset the global ChromaDB client (use if encountering initialization issues)"""
        global _chroma_client
        _chroma_client = None
        log_info("ChromaDB client reset")
