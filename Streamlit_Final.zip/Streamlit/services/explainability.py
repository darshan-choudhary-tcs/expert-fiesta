"""
Explainability Service
Tracks and explains AI decision-making process
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
from core.llm.llm_config import get_llm
from core.llm.prompts import get_explainability_prompt
from utils.logger import log_info, log_error


class ExplainabilityService:
    """Service for explainability and transparency"""

    def __init__(self):
        self.llm = get_llm(temperature=0.3)
        self.reasoning_chain = []

    def generate_explanation(
        self,
        query: str,
        response: str,
        sources: List[Dict[str, Any]],
        agent_trace: Optional[List[Dict]] = None
    ) -> Dict[str, Any]:
        """
        Generate human-readable explanation of AI response

        Returns:
            Explanation with reasoning steps
        """
        try:
            # Format sources for explanation
            sources_summary = "\n".join([
                f"- {s.get('metadata', {}).get('filename', 'Unknown')} "
                f"(relevance: {s.get('score', 0):.2f})"
                for s in sources[:5]
            ])

            # Generate explanation
            prompt = get_explainability_prompt()
            explanation_text = prompt.format(
                query=query,
                response=response,
                sources=sources_summary
            )

            llm_response = self.llm.invoke(explanation_text)
            explanation = llm_response.content

            # Structure explanation
            result = {
                'explanation': explanation,
                'query_interpretation': self._extract_section(explanation, 'interpreted'),
                'source_relevance': self._extract_section(explanation, 'relevant'),
                'construction': self._extract_section(explanation, 'constructed'),
                'confidence': self._extract_section(explanation, 'confidence'),
                'timestamp': datetime.utcnow().isoformat()
            }

            if agent_trace:
                result['agent_execution'] = agent_trace

            log_info("Generated explainability report")
            return result

        except Exception as e:
            log_error(f"Error generating explanation: {e}")
            return {
                'explanation': 'Explanation generation failed',
                'error': str(e)
            }

    def _extract_section(self, text: str, keyword: str) -> str:
        """Extract section from explanation text"""
        lines = text.split('\n')
        for i, line in enumerate(lines):
            if keyword.lower() in line.lower():
                # Return this line and next few lines
                return '\n'.join(lines[i:min(i+3, len(lines))])
        return ""

    def track_reasoning_step(
        self,
        step_name: str,
        input_data: Any,
        output_data: Any,
        metadata: Optional[Dict] = None
    ):
        """Track a step in the reasoning process"""
        step = {
            'step': step_name,
            'input': str(input_data)[:200],
            'output': str(output_data)[:200],
            'metadata': metadata or {},
            'timestamp': datetime.utcnow().isoformat()
        }
        self.reasoning_chain.append(step)
        log_info(f"Tracked reasoning step: {step_name}")

    def get_reasoning_chain(self) -> List[Dict]:
        """Get the complete reasoning chain"""
        return self.reasoning_chain

    def clear_reasoning_chain(self):
        """Clear the reasoning chain"""
        self.reasoning_chain = []

    def create_source_attribution(
        self,
        answer: str,
        sources: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Create detailed source attribution for answer

        Returns:
            List of attributed sources with details
        """
        attributions = []

        for i, source in enumerate(sources, 1):
            metadata = source.get('metadata', {})

            attribution = {
                'citation_id': i,
                'filename': metadata.get('filename', 'Unknown'),
                'chunk_index': metadata.get('chunk_index', '?'),
                'total_chunks': metadata.get('total_chunks', '?'),
                'relevance_score': round(source.get('score', 0.0), 3),
                'content_preview': source.get('document', '')[:300] + '...',
                'word_count': len(source.get('document', '').split()),
                'metadata': metadata
            }
            attributions.append(attribution)

        return attributions

    def generate_confidence_breakdown(
        self,
        sources: List[Dict[str, Any]],
        answer_length: int,
        model_confidence: float = 0.0
    ) -> Dict[str, Any]:
        """
        Generate detailed confidence breakdown

        Returns:
            Confidence metrics with explanation
        """
        try:
            # Calculate various confidence factors
            if sources:
                source_relevance = sum(s.get('score', 0) for s in sources) / len(sources)
                source_diversity = len(set(s.get('metadata', {}).get('filename', '') for s in sources))
            else:
                source_relevance = 0.0
                source_diversity = 0

            source_count = len(sources)
            answer_completeness = min(answer_length / 200, 1.0)  # Assume 200 words is complete

            # Overall confidence
            overall_confidence = (
                source_relevance * 0.4 +
                min(source_count / 5, 1.0) * 0.2 +
                min(source_diversity / 3, 1.0) * 0.2 +
                answer_completeness * 0.2
            )

            return {
                'overall_confidence': round(overall_confidence, 3),
                'source_relevance': round(source_relevance, 3),
                'source_count': source_count,
                'source_diversity': source_diversity,
                'answer_completeness': round(answer_completeness, 3),
                'confidence_level': self._get_confidence_level(overall_confidence)
            }

        except Exception as e:
            log_error(f"Error generating confidence breakdown: {e}")
            return {'overall_confidence': 0.5, 'error': str(e)}

    def _get_confidence_level(self, score: float) -> str:
        """Convert confidence score to level"""
        if score >= 0.8:
            return "High"
        elif score >= 0.6:
            return "Medium"
        elif score >= 0.4:
            return "Low"
        else:
            return "Very Low"
