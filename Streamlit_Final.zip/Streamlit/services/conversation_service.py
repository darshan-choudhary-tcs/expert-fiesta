"""
Conversation Service
Manages conversation history and context
"""

from typing import List, Dict, Optional, Any
from datetime import datetime
from models.user import ConversationHistory, get_session
from utils.logger import log_info, log_error
import json


class ConversationService:
    """Service for managing conversations"""

    @staticmethod
    def save_message(
        user_id: int,
        session_id: str,
        message_type: str,
        message_content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Save a message to conversation history"""
        db_session = get_session()
        try:
            conversation = ConversationHistory(
                user_id=user_id,
                session_id=session_id,
                message_type=message_type,
                message_content=message_content,
                meta_data=json.dumps(metadata) if metadata else None
            )

            db_session.add(conversation)
            db_session.commit()
            log_info(f"Saved {message_type} message for user {user_id}")
            return True

        except Exception as e:
            db_session.rollback()
            log_error(f"Error saving message: {e}")
            return False
        finally:
            db_session.close()

    @staticmethod
    def get_conversation_history(
        user_id: int,
        session_id: str,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get conversation history for a session"""
        db_session = get_session()
        try:
            messages = db_session.query(ConversationHistory)\
                .filter(
                    ConversationHistory.user_id == user_id,
                    ConversationHistory.session_id == session_id
                )\
                .order_by(ConversationHistory.timestamp.asc())\
                .limit(limit)\
                .all()

            return [msg.to_dict() for msg in messages]

        except Exception as e:
            log_error(f"Error fetching conversation: {e}")
            return []
        finally:
            db_session.close()

    @staticmethod
    def get_user_sessions(user_id: int, limit: int = 20) -> List[Dict[str, Any]]:
        """Get list of user's conversation sessions"""
        db_session = get_session()
        try:
            from sqlalchemy import func, distinct

            sessions = db_session.query(
                ConversationHistory.session_id,
                func.count(ConversationHistory.id).label('message_count'),
                func.max(ConversationHistory.timestamp).label('last_message'),
                func.min(ConversationHistory.timestamp).label('first_message')
            ).filter(
                ConversationHistory.user_id == user_id
            ).group_by(
                ConversationHistory.session_id
            ).order_by(
                func.max(ConversationHistory.timestamp).desc()
            ).limit(limit).all()

            return [{
                'session_id': s.session_id,
                'message_count': s.message_count,
                'last_message': s.last_message.isoformat() if s.last_message else None,
                'first_message': s.first_message.isoformat() if s.first_message else None
            } for s in sessions]

        except Exception as e:
            log_error(f"Error fetching sessions: {e}")
            return []
        finally:
            db_session.close()

    @staticmethod
    def delete_session(user_id: int, session_id: str) -> bool:
        """Delete a conversation session"""
        db_session = get_session()
        try:
            db_session.query(ConversationHistory).filter(
                ConversationHistory.user_id == user_id,
                ConversationHistory.session_id == session_id
            ).delete()

            db_session.commit()
            log_info(f"Deleted session {session_id} for user {user_id}")
            return True

        except Exception as e:
            db_session.rollback()
            log_error(f"Error deleting session: {e}")
            return False
        finally:
            db_session.close()

    @staticmethod
    def export_conversation(user_id: int, session_id: str, format: str = 'json') -> Optional[str]:
        """Export conversation in specified format"""
        messages = ConversationService.get_conversation_history(user_id, session_id)

        if not messages:
            return None

        if format == 'json':
            return json.dumps(messages, indent=2)
        elif format == 'markdown':
            md_lines = [f"# Conversation Export - {session_id}\n"]
            for msg in messages:
                role = msg['message_type'].capitalize()
                content = msg['message_content']
                timestamp = msg['timestamp']
                md_lines.append(f"## {role} ({timestamp})\n{content}\n")
            return '\n'.join(md_lines)
        else:
            return None
