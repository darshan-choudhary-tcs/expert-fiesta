"""
PII Scrubbing Service
Detects and removes personally identifiable information from text
"""

import scrubadub
from typing import Dict, List, Optional, Tuple
from utils.logger import log_info, log_error


class PIIScrubber:
    """Service for PII detection and scrubbing"""

    def __init__(self):
        """Initialize PII scrubber with default detectors"""
        # Create scrubber with default detectors
        self.scrubber = scrubadub.Scrubber()

        # Add additional detectors if available
        try:
            # Try to add common detectors
            from scrubadub.detectors import EmailDetector, PhoneDetector, UrlDetector
            # Detectors are automatically loaded by default
            pass
        except Exception as e:
            log_error(f"Error loading additional detectors: {e}")

    def scrub_text(
        self,
        text: str,
        replacement_type: str = "placeholder"
    ) -> Tuple[str, List[Dict]]:
        """
        Scrub PII from text

        Args:
            text: Input text to scrub
            replacement_type: Type of replacement ('placeholder')

        Returns:
            Tuple of (scrubbed_text, detected_entities)
        """
        try:
            # Detect PII entities
            detected_entities = []

            # Get filth items (detected PII)
            filth_list = self.scrubber.iter_filth(text)

            for filth in filth_list:
                detected_entities.append({
                    'type': filth.type,
                    'text': filth.text,
                    'start': filth.beg,
                    'end': filth.end,
                    'replacement': filth.replacement_string
                })

            # Clean the text (scrubadub currently supports only 'placeholder')
            scrubbed = self.scrubber.clean(text, replace_with='placeholder')

            log_info(f"Scrubbed {len(detected_entities)} PII entities from text")
            return scrubbed, detected_entities

        except Exception as e:
            log_error(f"Error scrubbing text: {e}", exc_info=True)
            return text, []

    def detect_pii(self, text: str) -> List[Dict]:
        """
        Detect PII without scrubbing

        Args:
            text: Input text to analyze

        Returns:
            List of detected PII entities
        """
        try:
            detected_entities = []
            filth_list = self.scrubber.iter_filth(text)

            for filth in filth_list:
                detected_entities.append({
                    'type': filth.type,
                    'text': filth.text,
                    'start': filth.beg,
                    'end': filth.end,
                    'confidence': getattr(filth, 'confidence', 1.0)
                })

            return detected_entities

        except Exception as e:
            log_error(f"Error detecting PII: {e}", exc_info=True)
            return []

    def scrub_document(
        self,
        text: str,
        enable_types: Optional[List[str]] = None,
        disable_types: Optional[List[str]] = None
    ) -> Dict:
        """
        Scrub document with custom detector configuration

        Args:
            text: Input text
            enable_types: List of detector types to enable
            disable_types: List of detector types to disable

        Returns:
            Dict with scrubbed text and statistics
        """
        try:
            # Create custom scrubber
            custom_scrubber = scrubadub.Scrubber()

            # Configure detectors
            if enable_types:
                for detector_type in enable_types:
                    try:
                        custom_scrubber.add_detector(
                            scrubadub.detectors.catalogue.get(detector_type)()
                        )
                    except Exception as e:
                        log_error(f"Could not add detector {detector_type}: {e}")

            # Detect entities
            entities = []
            filth_list = custom_scrubber.iter_filth(text)

            for filth in filth_list:
                if disable_types and filth.type in disable_types:
                    continue

                entities.append({
                    'type': filth.type,
                    'text': filth.text,
                    'start': filth.beg,
                    'end': filth.end
                })

            # Scrub text
            scrubbed_text = custom_scrubber.clean(text)

            # Calculate statistics
            entity_counts = {}
            for entity in entities:
                entity_type = entity['type']
                entity_counts[entity_type] = entity_counts.get(entity_type, 0) + 1

            return {
                'original_text': text,
                'scrubbed_text': scrubbed_text,
                'entities': entities,
                'statistics': {
                    'total_entities': len(entities),
                    'entity_counts': entity_counts,
                    'original_length': len(text),
                    'scrubbed_length': len(scrubbed_text)
                }
            }

        except Exception as e:
            log_error(f"Error scrubbing document: {e}", exc_info=True)
            return {
                'original_text': text,
                'scrubbed_text': text,
                'entities': [],
                'statistics': {
                    'total_entities': 0,
                    'entity_counts': {},
                    'original_length': len(text),
                    'scrubbed_length': len(text)
                }
            }

    @staticmethod
    def get_available_detectors() -> List[str]:
        """Get list of available PII detector types"""
        try:
            return list(scrubadub.detectors.catalogue._detectors.keys())
        except Exception:
            # Common detector types
            return [
                'email',
                'phone',
                'ssn',
                'name',
                'url',
                'credit_card',
                'address',
                'date_of_birth',
                'username',
                'password'
            ]

    @staticmethod
    def get_replacement_types() -> List[str]:
        """Get available replacement types"""
        return ['placeholder']
