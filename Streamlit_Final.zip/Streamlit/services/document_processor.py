"""
Document Processing Service
Handles document upload, text extraction, and chunking
"""

from typing import List, Dict, Tuple, Optional
import re
from pathlib import Path
from io import BytesIO

# Document processing imports
try:
    from pypdf import PdfReader
except ImportError:
    PdfReader = None

try:
    from docx import Document as DocxDocument
except ImportError:
    DocxDocument = None

from config.settings import settings
from utils.logger import log_info, log_error


class DocumentProcessor:
    """Service for processing uploaded documents"""

    @staticmethod
    def extract_text_from_pdf(file_content: bytes) -> Tuple[bool, str, str]:
        """
        Extract text from PDF file

        Returns:
            (success, text, error_message)
        """
        if not PdfReader:
            return False, "", "PyPDF library not available"

        try:
            pdf_file = BytesIO(file_content)
            reader = PdfReader(pdf_file)

            text_parts = []
            for page_num, page in enumerate(reader.pages):
                text = page.extract_text()
                if text.strip():
                    text_parts.append(f"[Page {page_num + 1}]\n{text}")

            full_text = "\n\n".join(text_parts)
            log_info(f"Extracted text from PDF ({len(reader.pages)} pages)")
            return True, full_text, ""

        except Exception as e:
            log_error(f"Error extracting PDF text: {e}", exc_info=True)
            return False, "", str(e)

    @staticmethod
    def extract_text_from_docx(file_content: bytes) -> Tuple[bool, str, str]:
        """
        Extract text from DOCX file

        Returns:
            (success, text, error_message)
        """
        if not DocxDocument:
            return False, "", "python-docx library not available"

        try:
            docx_file = BytesIO(file_content)
            doc = DocxDocument(docx_file)

            text_parts = []
            for para in doc.paragraphs:
                if para.text.strip():
                    text_parts.append(para.text)

            full_text = "\n\n".join(text_parts)
            log_info(f"Extracted text from DOCX ({len(doc.paragraphs)} paragraphs)")
            return True, full_text, ""

        except Exception as e:
            log_error(f"Error extracting DOCX text: {e}", exc_info=True)
            return False, "", str(e)

    @staticmethod
    def extract_text_from_txt(file_content: bytes) -> Tuple[bool, str, str]:
        """
        Extract text from TXT file

        Returns:
            (success, text, error_message)
        """
        try:
            # Try UTF-8 first, fallback to latin-1
            try:
                text = file_content.decode('utf-8')
            except UnicodeDecodeError:
                text = file_content.decode('latin-1')

            log_info("Extracted text from TXT file")
            return True, text, ""

        except Exception as e:
            log_error(f"Error extracting TXT text: {e}", exc_info=True)
            return False, "", str(e)

    @staticmethod
    def extract_text(filename: str, file_content: bytes) -> Tuple[bool, str, str]:
        """
        Extract text from file based on extension

        Returns:
            (success, text, error_message)
        """
        ext = filename.lower().split('.')[-1]

        if ext == 'pdf':
            return DocumentProcessor.extract_text_from_pdf(file_content)
        elif ext in ['docx', 'doc']:
            return DocumentProcessor.extract_text_from_docx(file_content)
        elif ext == 'txt':
            return DocumentProcessor.extract_text_from_txt(file_content)
        else:
            return False, "", f"Unsupported file type: {ext}"

    @staticmethod
    def chunk_text(
        text: str,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None
    ) -> List[str]:
        """
        Split text into chunks with overlap

        Args:
            text: Text to chunk
            chunk_size: Size of each chunk (default from settings)
            chunk_overlap: Overlap between chunks (default from settings)

        Returns:
            List of text chunks
        """
        chunk_size = chunk_size or settings.chunk_size
        chunk_overlap = chunk_overlap or settings.chunk_overlap

        if not text or not text.strip():
            return []

        # Clean text
        text = DocumentProcessor._clean_text(text)

        # Split by sentences first
        sentences = DocumentProcessor._split_sentences(text)

        chunks = []
        current_chunk = []
        current_length = 0

        for sentence in sentences:
            sentence_length = len(sentence)

            if current_length + sentence_length <= chunk_size:
                current_chunk.append(sentence)
                current_length += sentence_length
            else:
                # Save current chunk
                if current_chunk:
                    chunks.append(' '.join(current_chunk))

                # Start new chunk with overlap
                if chunk_overlap > 0 and current_chunk:
                    # Include last few sentences for overlap
                    overlap_sentences = []
                    overlap_length = 0
                    for s in reversed(current_chunk):
                        if overlap_length + len(s) <= chunk_overlap:
                            overlap_sentences.insert(0, s)
                            overlap_length += len(s)
                        else:
                            break
                    current_chunk = overlap_sentences
                    current_length = overlap_length
                else:
                    current_chunk = []
                    current_length = 0

                # Add current sentence
                current_chunk.append(sentence)
                current_length += sentence_length

        # Add final chunk
        if current_chunk:
            chunks.append(' '.join(current_chunk))

        log_info(f"Created {len(chunks)} chunks from text")
        return chunks

    @staticmethod
    def _clean_text(text: str) -> str:
        """Clean and normalize text"""
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        # Remove special characters but keep punctuation
        text = re.sub(r'[\x00-\x08\x0b-\x0c\x0e-\x1f\x7f-\x9f]', '', text)
        return text.strip()

    @staticmethod
    def _split_sentences(text: str) -> List[str]:
        """Split text into sentences"""
        # Simple sentence splitter
        sentences = re.split(r'(?<=[.!?])\s+', text)
        return [s.strip() for s in sentences if s.strip()]

    @staticmethod
    def create_metadata(
        filename: str,
        chunk_index: int,
        total_chunks: int,
        user_id: Optional[int] = None,
        additional_metadata: Optional[Dict] = None
    ) -> Dict:
        """Create metadata for a chunk"""
        metadata = {
            'filename': filename,
            'chunk_index': chunk_index,
            'total_chunks': total_chunks,
        }

        if user_id:
            metadata['user_id'] = user_id

        if additional_metadata:
            metadata.update(additional_metadata)

        return metadata
