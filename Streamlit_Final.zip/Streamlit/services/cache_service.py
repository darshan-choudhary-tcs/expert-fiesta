"""
Cache Service
Implements simple caching for LLM responses
"""

from typing import Optional, Dict, Any
import hashlib
import json
from datetime import datetime, timedelta
from models.user import get_session
from sqlalchemy import Column, Integer, String, Text, DateTime
from models.user import Base
from config.settings import settings
from utils.logger import log_info, log_error


class CacheEntry(Base):
    """Cache entry model"""
    __tablename__ = 'cache_entries'

    id = Column(Integer, primary_key=True)
    cache_key = Column(String(64), unique=True, index=True)
    cache_value = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime)


class CacheService:
    """Service for caching responses"""

    @staticmethod
    def _generate_key(query: str, context: str = "") -> str:
        """Generate cache key from query and context"""
        combined = f"{query}:{context}"
        return hashlib.sha256(combined.encode()).hexdigest()

    @staticmethod
    def get(query: str, context: str = "") -> Optional[Dict[str, Any]]:
        """Get cached response"""
        if not settings.cache_enabled:
            return None

        cache_key = CacheService._generate_key(query, context)
        db_session = get_session()

        try:
            entry = db_session.query(CacheEntry).filter(
                CacheEntry.cache_key == cache_key
            ).first()

            if entry:
                # Check if expired
                if entry.expires_at and entry.expires_at < datetime.utcnow():
                    # Delete expired entry
                    db_session.delete(entry)
                    db_session.commit()
                    return None

                log_info("Cache hit")
                return json.loads(entry.cache_value)

            return None

        except Exception as e:
            log_error(f"Cache get error: {e}")
            return None
        finally:
            db_session.close()

    @staticmethod
    def set(query: str, value: Dict[str, Any], context: str = "", ttl: Optional[int] = None) -> bool:
        """Set cached response"""
        if not settings.cache_enabled:
            return False

        cache_key = CacheService._generate_key(query, context)
        ttl = ttl or settings.cache_ttl_seconds
        expires_at = datetime.utcnow() + timedelta(seconds=ttl)

        db_session = get_session()

        try:
            # Check if entry exists
            entry = db_session.query(CacheEntry).filter(
                CacheEntry.cache_key == cache_key
            ).first()

            if entry:
                # Update existing
                entry.cache_value = json.dumps(value)
                entry.expires_at = expires_at
            else:
                # Create new
                entry = CacheEntry(
                    cache_key=cache_key,
                    cache_value=json.dumps(value),
                    expires_at=expires_at
                )
                db_session.add(entry)

            db_session.commit()
            log_info("Cached response")
            return True

        except Exception as e:
            db_session.rollback()
            log_error(f"Cache set error: {e}")
            return False
        finally:
            db_session.close()

    @staticmethod
    def clear_expired():
        """Clear expired cache entries"""
        db_session = get_session()
        try:
            deleted = db_session.query(CacheEntry).filter(
                CacheEntry.expires_at < datetime.utcnow()
            ).delete()

            db_session.commit()
            log_info(f"Cleared {deleted} expired cache entries")
            return deleted

        except Exception as e:
            db_session.rollback()
            log_error(f"Cache clear error: {e}")
            return 0
        finally:
            db_session.close()

    @staticmethod
    def clear_all():
        """Clear all cache entries"""
        db_session = get_session()
        try:
            deleted = db_session.query(CacheEntry).delete()
            db_session.commit()
            log_info(f"Cleared all {deleted} cache entries")
            return deleted

        except Exception as e:
            db_session.rollback()
            log_error(f"Cache clear error: {e}")
            return 0
        finally:
            db_session.close()
