"""
RAG Service
Implements Retrieval-Augmented Generation pipeline
"""

from typing import List, Dict, Optional, Any
from core.llm.llm_config import get_llm_with_token_counter
from core.llm.prompts import get_rag_prompt
from services.vector_store import VectorStoreService
from utils.logger import log_info, log_error
from utils.metrics import MetricsTracker
import time


class RAGService:
    """Service for RAG operations"""

    def __init__(self, collection_name: str = "default"):
        """Initialize RAG service"""
        self.vector_store = VectorStoreService(collection_name)
        self.llm, self.token_counter = get_llm_with_token_counter()
        self.prompt = get_rag_prompt()

    def query(
        self,
        question: str,
        k: int = 5,
        use_mmr: bool = True,
        user_id: Optional[int] = None,
        session_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Execute RAG query

        Args:
            question: User question
            k: Number of documents to retrieve
            use_mmr: Use MMR for diverse results
            user_id: User ID for metrics
            session_id: Session ID for metrics

        Returns:
            Dict with answer, sources, and metadata
        """
        start_time = time.time()

        try:
            # Reset token counter
            self.token_counter.reset()

            # Retrieve relevant documents
            log_info(f"Retrieving {k} documents for query")
            if use_mmr:
                docs = self.vector_store.mmr_search(question, k=k)
            else:
                docs = self.vector_store.similarity_search(question, k=k)

            if not docs:
                return {
                    'answer': "I couldn't find relevant information to answer your question.",
                    'sources': [],
                    'confidence': 0.0,
                    'num_sources': 0
                }

            # Format context
            context = self._format_context(docs)

            # Generate answer
            log_info("Generating answer with LLM")
            messages = self.prompt.format_messages(context=context, question=question)
            response = self.llm.invoke(messages)
            answer = response.content

            # Calculate average relevance
            avg_relevance = sum(doc['score'] for doc in docs) / len(docs)

            # Record metrics
            latency_ms = (time.time() - start_time) * 1000
            token_usage = self.token_counter.get_usage()

            MetricsTracker.record_metric(
                metric_type='query',
                operation='rag_query',
                user_id=user_id,
                session_id=session_id,
                latency_ms=latency_ms,
                tokens_used=token_usage['total_tokens'],
                tokens_prompt=token_usage['prompt_tokens'],
                tokens_completion=token_usage['completion_tokens'],
                num_documents_retrieved=len(docs),
                avg_relevance_score=avg_relevance
            )

            log_info(f"RAG query completed in {latency_ms:.2f}ms")

            return {
                'answer': answer,
                'sources': docs,
                'confidence': avg_relevance,
                'num_sources': len(docs),
                'latency_ms': latency_ms,
                'tokens_used': token_usage['total_tokens']
            }

        except Exception as e:
            log_error(f"Error in RAG query: {e}", exc_info=True)

            # Record error metric
            MetricsTracker.record_metric(
                metric_type='query',
                operation='rag_query',
                user_id=user_id,
                session_id=session_id,
                error_message=str(e)
            )

            return {
                'answer': f"An error occurred: {str(e)}",
                'sources': [],
                'confidence': 0.0,
                'num_sources': 0,
                'error': str(e)
            }

    def _format_context(self, docs: List[Dict[str, Any]]) -> str:
        """Format retrieved documents as context"""
        context_parts = []
        for i, doc in enumerate(docs, 1):
            metadata = doc.get('metadata', {})
            filename = metadata.get('filename', 'Unknown')
            chunk_idx = metadata.get('chunk_index', '?')

            context_parts.append(
                f"[Source {i}: {filename}, Chunk {chunk_idx}]\n"
                f"{doc['document']}\n"
                f"(Relevance: {doc['score']:.3f})"
            )

        return "\n\n---\n\n".join(context_parts)

    def add_documents(
        self,
        texts: List[str],
        metadatas: Optional[List[Dict]] = None
    ) -> List[str]:
        """Add documents to vector store"""
        return self.vector_store.add_documents(texts, metadatas)
