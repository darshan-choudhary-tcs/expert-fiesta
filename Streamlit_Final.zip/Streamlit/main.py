"""
Main Streamlit Application Entry Point
"""

import streamlit as st
from utils.session import init_session_state, is_authenticated, get_current_page, navigate_to
from models import init_db
from config.settings import settings

# Page configuration
st.set_page_config(
    page_title=settings.app_name,
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize database
try:
    init_db()
except Exception as e:
    st.error(f"Database initialization error: {e}")

# Initialize session state
init_session_state()

# Load custom CSS
try:
    with open("static/custom.css") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
except FileNotFoundError:
    pass  # CSS file optional

# Import pages
from app.pages import login, register, talk_to_data, knowledge_base_setup, explainability_dashboard, admin, pii_scrubber, agent_storefront

# Page routing
def main():
    """Main application router"""

    current_page = get_current_page()

    # Sidebar
    if is_authenticated():
      with st.sidebar:
        st.title(settings.app_name)

        from utils.session import get_current_user, logout_user, is_admin

        user = get_current_user()
        st.subheader(f"Welcome, **{user['username']}**!")

        # Navigation menu
        pages = ["Talk to Data", "Knowledge Base Setup", "PII Scrubber", "Explainability", "Agent Storefront"]

        if is_admin():
            pages.append("Admin Panel")

        # Map page names to page choices
        page_map = {
            "Talk to Data": "talk_to_data",
            "Knowledge Base Setup": "knowledge_base_setup",
            "PII Scrubber": "pii_scrubber",
            "Explainability": "explainability",
            "Admin Panel": "admin",
            "Agent Storefront": "agent_storefront"
        }

        # Reverse map to find current page index
        reverse_map = {v: k for k, v in page_map.items()}
        current_choice = reverse_map.get(current_page, "Talk to Data")
        page_index = pages.index(current_choice) if current_choice in pages else 0

        # Define callback for navigation
        def on_auth_page_change():
            page_choice = st.session_state.auth_nav
            if page_choice in page_map:
                target_page = page_map[page_choice]
                if target_page != st.session_state.get('current_page'):
                    st.session_state.current_page = target_page

        st.radio(
            "Navigation",
            pages,
            index=page_index,
            key="auth_nav",
            on_change=on_auth_page_change
        )

        st.markdown("---")

        if st.button("Logout", use_container_width=True):
            logout_user()
            st.rerun()


    # Main content area
    if not is_authenticated():
        if current_page == "register":
            register.show()
        else:
            login.show()
    else:
        if current_page == "knowledge_base_setup":
            knowledge_base_setup.show()
        elif current_page == "pii_scrubber":
            pii_scrubber.show()
        elif current_page == "explainability":
            explainability_dashboard.show()
        elif current_page == "admin":
            admin.show()
        elif current_page == "agent_storefront":
            agent_storefront.show()
        else:
            talk_to_data.show()


if __name__ == "__main__":
    main()
