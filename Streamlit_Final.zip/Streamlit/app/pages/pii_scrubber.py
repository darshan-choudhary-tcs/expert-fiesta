"""
PII Scrubbing Page
Detect and remove personally identifiable information from text
"""

import streamlit as st
from services.pii_scrubber import PIIScrubber
from utils.session import require_auth, get_current_user
from utils.logger import log_info
import pandas as pd
from utils.logger import log_info, log_error

@require_auth
def show():
    """Display PII scrubbing page"""

    st.title("PII Scrubbing")
    st.markdown("Detect and remove personally identifiable information from text securely")

    user = get_current_user()

    # Initialize scrubber
    scrubber = PIIScrubber()

    # Create tabs
    tabs = st.tabs(["Scrub Text", "Detect Only", "Batch Processing"])

    # Tab 1: Scrub Text
    with tabs[0]:
        st.subheader("Scrub PII from Text")
        st.markdown("Enter text below to automatically detect and remove PII")

        col1, col2 = st.columns([2, 1])

        with col1:
            replacement_type = st.selectbox(
                "Replacement Type",
                options=PIIScrubber.get_replacement_types(),
                format_func=lambda x: 'Placeholder ({{NAME}}, {{EMAIL}})' if x == 'placeholder' else x,
                help="Choose how to replace detected PII"
            )

        with col2:
            show_entities = st.checkbox("Show Detected Entities", value=True)

        # Text input
        input_text = st.text_area(
            "Input Text",
            height=200,
            placeholder="Enter text containing PII (e.g., My name is John Smith and my email is john@example.com...)",
            help="Paste or type text to scrub PII"
        )

        scrub_button = st.button("Scrub PII", type="primary", use_container_width=True)

        # Use sample text if available
        if 'pii_sample_text' in st.session_state:
            input_text = st.session_state.pii_sample_text
            del st.session_state.pii_sample_text

        if scrub_button and input_text:
            with st.spinner("Scrubbing PII..."):
                scrubbed_text, entities = scrubber.scrub_text(input_text, replacement_type)

                # Display results
                st.markdown("---")
                st.subheader("Results")

                # Statistics
                col1, col2, col3 = st.columns(3)

                with col1:
                    st.metric("PII Entities Found", len(entities))

                with col2:
                    entity_types = len(set(e['type'] for e in entities))
                    st.metric("Entity Types", entity_types)

                with col3:
                    reduction = len(input_text) - len(scrubbed_text)
                    st.metric("Characters Removed", reduction)

                # Show detected entities
                if show_entities and entities:
                    st.markdown("#### Detected PII Entities")

                    # Group by type
                    entities_by_type = {}
                    for entity in entities:
                        etype = entity['type']
                        if etype not in entities_by_type:
                            entities_by_type[etype] = []
                        entities_by_type[etype].append(entity)

                    # Display by type
                    for etype, elist in entities_by_type.items():
                        with st.expander(f"**{etype.upper()}** ({len(elist)} found)"):
                            for entity in elist:
                                st.markdown(f"- `{entity['text']}` → `{entity['replacement']}`")

                # Display scrubbed text
                st.markdown("#### Scrubbed Text")
                st.text_area("Scrubbed Output", value=scrubbed_text, height=200, key="scrubbed_output")

                # Download button
                st.download_button(
                    label="Download Scrubbed Text",
                    data=scrubbed_text,
                    file_name="scrubbed_text.txt",
                    mime="text/plain"
                )

                log_info(f"User {user['username']} scrubbed text with {len(entities)} PII entities")

    # Tab 2: Detect Only
    with tabs[1]:
        st.subheader("PII Detection (No Scrubbing)")
        st.markdown("Analyze text to detect PII without modifying it")

        detect_text = st.text_area(
            "Text to Analyze",
            height=200,
            placeholder="Enter text to analyze for PII...",
            key="detect_input"
        )

        if st.button("Detect PII", type="primary", use_container_width=True, key="detect_btn"):
            if detect_text:
                with st.spinner("Analyzing..."):
                    entities = scrubber.detect_pii(detect_text)

                    if entities:
                        st.success(f"Found {len(entities)} PII entities")

                        # Create DataFrame
                        df = pd.DataFrame(entities)

                        # Display table
                        st.dataframe(
                            df,
                            use_container_width=True,
                            hide_index=True
                        )

                        # Visualization
                        st.markdown("#### PII Distribution")

                        entity_counts = df['type'].value_counts()
                        st.bar_chart(entity_counts)

                    else:
                        st.info("No PII detected in the text")

                    log_info(f"User {user['username']} detected PII in text")
            else:
                st.warning("Please enter text to analyze")

    # Tab 3: Batch Processing
    with tabs[2]:
        st.subheader("Batch PII Scrubbing")
        st.markdown("Upload a text file or process multiple texts at once")

        # File uploader
        uploaded_file = st.file_uploader(
            "Upload Text File",
            type=['txt', 'csv'],
            help="Upload a .txt or .csv file to scrub PII"
        )

        if uploaded_file:
            try:
                # Read file
                if uploaded_file.name.endswith('.txt'):
                    content = uploaded_file.read().decode('utf-8')

                    with st.spinner("Processing file..."):
                        result = scrubber.scrub_document(content)

                        # Display statistics
                        st.markdown("#### Processing Statistics")

                        col1, col2, col3, col4 = st.columns(4)

                        with col1:
                            st.metric("Total Entities", result['statistics']['total_entities'])

                        with col2:
                            st.metric("Original Length", result['statistics']['original_length'])

                        with col3:
                            st.metric("Scrubbed Length", result['statistics']['scrubbed_length'])

                        with col4:
                            reduction_pct = (
                                (result['statistics']['original_length'] - result['statistics']['scrubbed_length'])
                                / result['statistics']['original_length'] * 100
                            )
                            st.metric("Reduction", f"{reduction_pct:.1f}%")

                        # Entity breakdown
                        if result['statistics']['entity_counts']:
                            st.markdown("#### Entity Breakdown")

                            entity_df = pd.DataFrame([
                                {'Type': k, 'Count': v}
                                for k, v in result['statistics']['entity_counts'].items()
                            ])

                            col1, col2 = st.columns([1, 2])

                            with col1:
                                st.dataframe(entity_df, use_container_width=True, hide_index=True)

                            with col2:
                                st.bar_chart(entity_df.set_index('Type'))

                        # Download scrubbed file
                        st.download_button(
                            label="Download Scrubbed File",
                            data=result['scrubbed_text'],
                            file_name=f"scrubbed_{uploaded_file.name}",
                            mime="text/plain"
                        )

                elif uploaded_file.name.endswith('.csv'):
                    # For CSV, process each row
                    df = pd.read_csv(uploaded_file)

                    st.markdown("#### CSV Preview")
                    st.dataframe(df.head(), use_container_width=True)

                    # Select column to scrub
                    text_column = st.selectbox(
                        "Select column to scrub",
                        options=df.columns.tolist()
                    )

                    if st.button("Process CSV", type="primary"):
                        with st.spinner("Processing CSV..."):
                            scrubbed_values = []
                            total_entities = 0

                            progress_bar = st.progress(0)

                            for idx, value in enumerate(df[text_column]):
                                if pd.notna(value):
                                    scrubbed, entities = scrubber.scrub_text(str(value))
                                    scrubbed_values.append(scrubbed)
                                    total_entities += len(entities)
                                else:
                                    scrubbed_values.append(value)

                                progress_bar.progress((idx + 1) / len(df))

                            # Create new DataFrame
                            df[f'{text_column}_scrubbed'] = scrubbed_values

                            st.success(f"Processed {len(df)} rows, found {total_entities} PII entities")

                            # Show results
                            st.dataframe(df, use_container_width=True)

                            # Download
                            csv = df.to_csv(index=False)
                            st.download_button(
                                label="Download Scrubbed CSV",
                                data=csv,
                                file_name=f"scrubbed_{uploaded_file.name}",
                                mime="text/csv"
                            )

            except Exception as e:
                st.error(f"Error processing file: {str(e)}")
                log_error(f"Error in PII batch processing: {e}", exc_info=True)
        else:
            st.info("Upload a file to begin batch processing")

    # Information section
    st.markdown("---")
    with st.expander("About PII Scrubbing"):
        st.markdown("""
        ### What is PII?

        **Personally Identifiable Information (PII)** is any data that can identify a specific individual.

        **Common PII Types Detected:**
        - Email Addresses: john@example.com
        - Phone Numbers: (555) 123-4567
        - Social Security Numbers: 123-45-6789
        - Names: First, middle, and last names
        - Addresses: Street addresses and locations
        - Credit Card Numbers: Financial information
        - URLs: Web addresses
        - Usernames & Passwords: Credentials

        ### Replacement Types

        1. **Placeholder**: Replaces with generic labels like `{{EMAIL}}`, `{{PHONE}}`
        2. **Hash**: Replaces with SHA256 hash for consistency
        3. **Fake**: Replaces with realistic fake data

        ### Best Practices

        - Always scrub PII before sharing data externally
        - Review scrubbed output to ensure accuracy
        - Use appropriate replacement type for your use case
        - Keep original data secure and separate
        """)


if __name__ == "__main__":
    show()
