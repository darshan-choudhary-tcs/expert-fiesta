"""
Main Dashboard - Chat Interface
"""

import streamlit as st
from utils.session import require_auth, get_current_user_id, add_to_chat_history, get_chat_history, set_explainability_data, add_agent_trace
from services.rag_service import RAGService
from core.agents.agent_graph import MultiAgentSystem
from services.grounding import GroundingService
from services.explainability import ExplainabilityService
from services.vector_store import VectorStoreService
from utils.logger import log_info
import time


@require_auth
def show():
    """Display main dashboard"""

    st.title("Talk to Data")
    st.markdown("Ask questions and get AI-powered answers with RAG or Multi-Agent support")

    # Mode selection
    col1, col2, col3 = st.columns([2, 2, 1])

    with col1:
        mode = st.selectbox(
            "Select Mode",
            ["RAG (Document Search)", "Multi-Agent System"],
            help="Choose between RAG for document-based answers or Multi-Agent for complex reasoning"
        )

    with col2:
        # Dynamic collection list from ChromaDB
        collections = VectorStoreService.list_collections()
        available_collections = list(collections) if collections else []

        # Fallback to 'default' if none exist yet (will be auto-created on first upload)
        if not available_collections:
            st.info("No collections found yet. Upload documents to create one.")
            available_collections = ["default"]

        # Determine initial selection based on session state
        prev_collection = st.session_state.get('current_collection')
        initial_index = 0
        if prev_collection and prev_collection in available_collections:
            initial_index = available_collections.index(prev_collection)

        collection = st.selectbox(
            "Document Collection",
            available_collections,
            index=initial_index,
            help="Select which document collection to search"
        )

        # Persist selection only if changed
        if prev_collection != collection:
            st.session_state['current_collection'] = collection

    with col3:
        show_explainability = st.checkbox("Show Insights", value=True)

    # Chat history display
    st.markdown("### Conversation")

    chat_container = st.container()

    with chat_container:
        history = get_chat_history()

        for msg in history:
            role = msg.get('role', 'user')
            content = msg.get('content', '')

            if role == 'user':
                st.chat_message("user").write(content)
            elif role == 'assistant':
                st.chat_message("assistant").write(content)

    # Query input
    query = st.chat_input("Ask me anything...")

    if query:
        # Add user message to history
        add_to_chat_history('user', query)
        st.chat_message("user").write(query)

        # Process query based on mode
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    user_id = get_current_user_id()

                    if "RAG" in mode:
                        # RAG mode
                        rag_service = RAGService(collection)
                        result = rag_service.query(
                            query,
                            k=5,
                            use_mmr=True,
                            user_id=user_id,
                            session_id=st.session_state.session_id
                        )

                        answer = result['answer']
                        sources = result.get('sources', [])

                        st.write(answer)

                        # Store explainability data
                        if show_explainability and sources:
                            grounding = GroundingService()
                            explainability = ExplainabilityService()

                            citations = grounding.generate_citations(answer, sources)
                            confidence = grounding.calculate_confidence(answer, sources, query)

                            set_explainability_data({
                                'sources': sources,
                                'citations': citations,
                                'confidence': confidence,
                                'mode': 'RAG'
                            })

                    else:
                        # Multi-Agent mode
                        agent_system = MultiAgentSystem()
                        result = agent_system.process_query(query)

                        answer = result['answer']
                        agent_trace = result.get('agent_trace', [])

                        st.write(answer)

                        # Store explainability data
                        if show_explainability:
                            set_explainability_data({
                                'agent_trace': agent_trace,
                                'selected_agent': result.get('selected_agent', 'UNKNOWN'),
                                'mode': 'Multi-Agent'
                            })

                            # Add to session traces
                            for trace in agent_trace:
                                add_agent_trace(
                                    trace.get('agent', 'Unknown'),
                                    trace.get('action', 'Unknown'),
                                    trace.get('output', '')
                                )

                    # Add assistant response to history
                    add_to_chat_history('assistant', answer, {'mode': mode})

                    # Show metrics
                    if 'latency_ms' in result:
                        st.caption(f"Response time: {result['latency_ms']:.0f}ms")
                    if 'tokens_used' in result:
                        st.caption(f"Tokens used: {result['tokens_used']}")

                except Exception as e:
                    error_msg = f"An error occurred: {str(e)}"
                    st.error(error_msg)
                    add_to_chat_history('assistant', error_msg, {'error': True})

        st.rerun()

    # Sidebar with explainability
    if show_explainability:
        with st.sidebar:
            st.markdown("---")
            st.subheader("Insights & Explainability")

            explainability_data = st.session_state.get('explainability_data')

            if explainability_data:
                mode = explainability_data.get('mode', 'Unknown')

                st.markdown(f"**Mode:** {mode}")

                if mode == 'RAG':
                    sources = explainability_data.get('sources', [])
                    confidence = explainability_data.get('confidence', 0)

                    st.metric("Confidence", f"{confidence:.1%}")

                    st.markdown("**Sources Used:**")
                    for i, source in enumerate(sources[:3], 1):
                        with st.expander(f"Source {i} ({source.get('score', 0):.2f})"):
                            st.markdown(f"**File:** {source.get('metadata', {}).get('filename', 'Unknown')}")
                            st.markdown(f"**Relevance:** {source.get('score', 0):.3f}")
                            st.text(source.get('document', '')[:300] + "...")

                elif mode == 'Multi-Agent':
                    agent_trace = explainability_data.get('agent_trace', [])
                    selected = explainability_data.get('selected_agent', 'Unknown')

                    st.markdown(f"**Selected Agent:** {selected}")
                    st.markdown(f"**Steps:** {len(agent_trace)}")

                    st.markdown("**Execution Trace:**")
                    for trace in agent_trace:
                        with st.expander(f"{trace.get('agent', 'Unknown')} - {trace.get('action', 'Unknown')}"):
                            st.json(trace)
            else:
                st.info("Ask a question to see insights")

    # Action buttons
    st.markdown("---")
    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("Clear Chat", use_container_width=True):
            from utils.session import clear_chat_history
            clear_chat_history()
            st.rerun()

    with col2:
        if st.button("Save Conversation", use_container_width=True):
            st.info("Conversation saved automatically")

    with col3:
        if st.button("View History", use_container_width=True):
            st.info("View conversation history in Explainability Dashboard")


if __name__ == "__main__":
    show()
