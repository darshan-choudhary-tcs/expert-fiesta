"""
Explainability Dashboard Page
"""

import streamlit as st
from utils.session import require_auth, get_explainability_data, get_agent_traces
from services.explainability import ExplainabilityService
from utils.logger import log_info
import plotly.graph_objects as go


@require_auth
def show():
    """Display explainability dashboard"""

    st.title("Explainability Dashboard")
    st.markdown("Understand how the AI makes decisions and generates responses")

    tabs = st.tabs(["Current Session", "Source Attribution", "Agent Execution", "Confidence Metrics"])

    explainability_data = get_explainability_data()
    agent_traces = get_agent_traces()

    # Tab 1: Current Session Overview
    with tabs[0]:
        st.subheader("Current Session Overview")

        if not explainability_data:
            st.info("No data available. Ask a question in the Dashboard to see explainability insights.")
        else:
            mode = explainability_data.get('mode', 'Unknown')

            col1, col2, col3 = st.columns(3)

            with col1:
                st.metric("Mode", mode)

            with col2:
                if mode == 'RAG':
                    sources = explainability_data.get('sources', [])
                    st.metric("Sources Used", len(sources))
                else:
                    st.metric("Agent Steps", len(explainability_data.get('agent_trace', [])))

            with col3:
                confidence = explainability_data.get('confidence', 0)
                st.metric("Confidence", f"{confidence:.1%}" if confidence else "N/A")

            st.markdown("---")

            if mode == 'RAG':
                st.markdown("### Retrieved Documents")
                sources = explainability_data.get('sources', [])

                for i, source in enumerate(sources, 1):
                    with st.expander(f"Source {i} - {source.get('metadata', {}).get('filename', 'Unknown')}"):
                        col1, col2 = st.columns([1, 3])

                        with col1:
                            score = source.get('score', 0)
                            st.metric("Relevance Score", f"{score:.3f}")

                            # Progress bar for relevance (clamped to [0,1])
                            progress_val = max(0.0, min(1.0, float(score)))
                            st.progress(progress_val)

                        with col2:
                            st.markdown("**Document Content:**")
                            st.text(source.get('document', '')[:500] + "...")

                            metadata = source.get('metadata', {})
                            st.json(metadata)

            elif mode == 'Multi-Agent':
                st.markdown("### Agent Execution Flow")

                agent_trace = explainability_data.get('agent_trace', [])

                for i, trace in enumerate(agent_trace, 1):
                    with st.expander(f"Step {i}: {trace.get('agent', 'Unknown')} - {trace.get('action', 'Unknown')}"):
                        st.json(trace)

    # Tab 2: Source Attribution
    with tabs[1]:
        st.subheader("Source Attribution & Citations")

        if explainability_data and explainability_data.get('mode') == 'RAG':
            sources = explainability_data.get('sources', [])

            if sources:
                explainability_service = ExplainabilityService()
                attributions = explainability_service.create_source_attribution("", sources)

                st.markdown("### Detailed Source Information")

                for attr in attributions:
                    with st.container():
                        st.markdown(f"#### Citation [{attr['citation_id']}] - {attr['filename']}")

                        col1, col2, col3 = st.columns(3)

                        with col1:
                            st.metric("Relevance Score", f"{attr['relevance_score']:.3f}")

                        with col2:
                            st.metric("Word Count", attr['word_count'])

                        with col3:
                            st.metric("Chunk", f"{attr['chunk_index']}/{attr['total_chunks']}")

                        with st.expander("View Content"):
                            st.text(attr['content_preview'])

                        st.markdown("---")
            else:
                st.info("No sources available for attribution")
        else:
            st.info("Source attribution is only available for RAG mode queries")

    # Tab 3: Agent Execution
    with tabs[2]:
        st.subheader("Agent Execution Trace")

        if agent_traces:
            st.markdown(f"**Total Steps:** {len(agent_traces)}")

            # Visualize agent flow
            st.markdown("### Agent Flow Diagram")

            # Create timeline visualization
            agents = [trace['agent'] for trace in agent_traces]
            actions = [trace['action'] for trace in agent_traces]

            fig = go.Figure()

            fig.add_trace(go.Scatter(
                x=list(range(len(agent_traces))),
                y=agents,
                mode='lines+markers+text',
                text=actions,
                textposition='top center',
                marker=dict(size=15, color='lightblue'),
                line=dict(width=2, color='blue')
            ))

            fig.update_layout(
                title="Agent Execution Timeline",
                xaxis_title="Step",
                yaxis_title="Agent",
                height=400
            )

            st.plotly_chart(fig, use_container_width=True)

            # Detailed trace
            st.markdown("### Detailed Execution Log")

            for i, trace in enumerate(agent_traces, 1):
                with st.expander(f"Step {i}: {trace['agent']} - {trace['action']}"):
                    st.json(trace)
        else:
            st.info("No agent execution traces available. Use Multi-Agent mode in the Dashboard.")

    # Tab 4: Confidence Metrics
    with tabs[3]:
        st.subheader("Confidence & Quality Metrics")

        if explainability_data and explainability_data.get('mode') == 'RAG':
            sources = explainability_data.get('sources', [])

            if sources:
                explainability_service = ExplainabilityService()

                # Calculate confidence breakdown
                confidence_breakdown = explainability_service.generate_confidence_breakdown(
                    sources,
                    answer_length=200  # Default
                )

                st.markdown("### Confidence Breakdown")

                col1, col2, col3 = st.columns(3)

                with col1:
                    overall = confidence_breakdown.get('overall_confidence', 0)
                    st.metric("Overall Confidence", f"{overall:.1%}")
                    st.progress(max(0.0, min(1.0, float(overall))))

                with col2:
                    source_rel = confidence_breakdown.get('source_relevance', 0)
                    st.metric("Source Relevance", f"{source_rel:.1%}")
                    st.progress(max(0.0, min(1.0, float(source_rel))))

                with col3:
                    level = confidence_breakdown.get('confidence_level', 'Unknown')
                    st.metric("Confidence Level", level)

                st.markdown("---")

                # Detailed metrics
                col1, col2 = st.columns(2)

                with col1:
                    st.markdown("**Factors:**")
                    st.markdown(f"- Source Count: {confidence_breakdown.get('source_count', 0)}")
                    st.markdown(f"- Source Diversity: {confidence_breakdown.get('source_diversity', 0)}")

                with col2:
                    st.markdown("**Quality Indicators:**")
                    completeness = confidence_breakdown.get('answer_completeness', 0)
                    st.markdown(f"- Answer Completeness: {completeness:.1%}")

                # Relevance distribution
                st.markdown("### Source Relevance Distribution")

                scores = [s.get('score', 0) for s in sources]
                filenames = [s.get('metadata', {}).get('filename', f'Source {i}') for i, s in enumerate(sources, 1)]

                fig = go.Figure(data=[
                    go.Bar(x=filenames, y=scores, marker_color='lightblue')
                ])

                fig.update_layout(
                    title="Relevance Scores by Source",
                    xaxis_title="Source",
                    yaxis_title="Relevance Score",
                    height=400
                )

                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No sources available for confidence metrics")
        else:
            st.info("Confidence metrics are only available for RAG mode queries")


if __name__ == "__main__":
    show()
