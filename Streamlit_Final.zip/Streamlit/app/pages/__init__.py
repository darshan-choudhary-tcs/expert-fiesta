"""
App Pages Package Initializer
"""

from app.pages import knowledge_base_setup, login, register, explainability_dashboard, admin, pii_scrubber, agent_storefront, talk_to_data

__all__ = [
    'login',
    'register',
    'talk_to_data',
    'knowledge_base_setup',
    'pii_scrubber',
    'explainability_dashboard',
    'admin',
    'agent_storefront'
]
