"""
Admin Panel Page
"""

import streamlit as st
from utils.session import require_admin
from utils.metrics import MetricsTracker
from models.user import get_session, User
from models.document import UserDocument
from models.metrics import PerformanceMetric
from datetime import datetime, timedelta
import plotly.graph_objects as go
from utils.ollama_helper import (
    check_ollama_connection,
    list_ollama_models,
    get_recommended_models,
    format_model_size
)


@require_admin
def show():
    """Display admin panel"""

    st.title("Admin Panel")
    st.markdown("System monitoring and management")

    tabs = st.tabs(["System Metrics", "Users", "Documents", "Settings", "System Actions"])

    # Tab 1: System Metrics
    with tabs[0]:
        st.subheader("System Performance Metrics")

        # Time period selector
        period = st.selectbox("Time Period", [7, 14, 30], format_func=lambda x: f"Last {x} days")

        # Fetch metrics
        system_metrics = MetricsTracker.get_system_metrics(days=period)

        if system_metrics:
            # Overview metrics
            col1, col2, col3, col4 = st.columns(4)

            with col1:
                st.metric("Total Queries", system_metrics.get('total_queries', 0))

            with col2:
                st.metric("Avg Latency", f"{system_metrics.get('avg_latency_ms', 0):.0f}ms")

            with col3:
                st.metric("Total Tokens", f"{system_metrics.get('total_tokens_used', 0):,}")

            with col4:
                st.metric("Cache Hit Rate", f"{system_metrics.get('cache_hit_rate', 0):.1f}%")

            st.markdown("---")

            # Additional metrics
            col1, col2 = st.columns(2)

            with col1:
                st.metric("Avg Relevance Score", f"{system_metrics.get('avg_relevance_score', 0):.3f}")

            with col2:
                st.metric("Error Rate", f"{system_metrics.get('error_rate', 0):.2f}%")

            # Agent performance
            st.markdown("### Agent Performance")

            agent_metrics = MetricsTracker.get_agent_performance(days=period)

            if agent_metrics:
                for agent in agent_metrics:
                    with st.expander(f"{agent['agent_name']} - {agent['executions']} executions"):
                        col1, col2, col3 = st.columns(3)

                        with col1:
                            st.metric("Avg Latency", f"{agent['avg_latency_ms']:.0f}ms")

                        with col2:
                            st.metric("Avg Steps", f"{agent['avg_steps']:.1f}")

                        with col3:
                            st.metric("Success Rate", f"{agent['success_rate']:.1f}%")
            else:
                st.info("No agent performance data available")
        else:
            st.info("No system metrics available for the selected period")

    # Tab 2: Users
    with tabs[1]:
        st.subheader("User Management")

        db_session = get_session()
        try:
            users = db_session.query(User).all()

            st.markdown(f"**Total Users:** {len(users)}")

            # Users table
            from utils.auth import ROLES, AuthService
            role_options = sorted(list(ROLES))

            for user in users:
                with st.expander(f"{user.username} ({user.email})"):
                    col_meta, col_actions = st.columns([2, 2])

                    with col_meta:
                        st.markdown(f"**ID:** {user.id}")
                        st.markdown(f"**Full Name:** {user.full_name or 'N/A'}")
                        st.markdown(f"**Active:** {'Yes' if user.is_active else 'No'}")
                        st.markdown(f"**Role:** {user.role if hasattr(user, 'role') else ('admin' if user.is_admin else 'user')} ")
                        st.markdown(f"**Created:** {user.created_at.strftime('%Y-%m-%d %H:%M') if user.created_at else 'N/A'}")
                        st.markdown(f"**Last Login:** {user.last_login.strftime('%Y-%m-%d %H:%M') if user.last_login else 'Never'}")

                    with col_actions:
                        # Role management
                        new_role = st.selectbox(
                            "Change Role",
                            role_options,
                            index=role_options.index(user.role if hasattr(user, 'role') and user.role in role_options else 'user'),
                            key=f"role_select_{user.id}"
                        )
                        if st.button("Update Role", key=f"update_role_{user.id}"):
                            ok, msg = AuthService.update_user_role(user.id, new_role)
                            if ok:
                                st.success(msg)
                                db_session.commit()
                                st.rerun()
                            else:
                                st.error(msg)

                        # Activation / deactivation
                        if not user.is_active:
                            if st.button("Activate", key=f"activate_{user.id}"):
                                user.is_active = True
                                db_session.commit()
                                st.success("User activated")
                                st.rerun()
                        else:
                            if st.button("Deactivate", key=f"deactivate_{user.id}"):
                                user.is_active = False
                                db_session.commit()
                                st.warning("User deactivated")
                                st.rerun()

                        # User recent queries metric
                        user_metrics = MetricsTracker.get_user_metrics(user.id, limit=10)
                        st.markdown(f"**Recent Queries:** {len(user_metrics)}")

        finally:
            db_session.close()

    # Tab 3: Documents
    with tabs[2]:
        st.subheader("Document Management")

        db_session = get_session()
        try:
            from sqlalchemy import func

            # Document statistics
            total_docs = db_session.query(func.count(UserDocument.id)).scalar()
            total_size = db_session.query(func.sum(UserDocument.file_size)).scalar() or 0
            total_chunks = db_session.query(func.sum(UserDocument.num_chunks)).scalar() or 0

            col1, col2, col3 = st.columns(3)

            with col1:
                st.metric("Total Documents", total_docs)

            with col2:
                st.metric("Total Size", f"{total_size / (1024*1024):.1f} MB")

            with col3:
                st.metric("Total Chunks", total_chunks)

            st.markdown("---")

            # Recent documents
            st.markdown("### Recent Documents")

            recent_docs = db_session.query(UserDocument).order_by(
                UserDocument.upload_date.desc()
            ).limit(20).all()

            for doc in recent_docs:
                with st.expander(f"{doc.filename}"):
                    col1, col2 = st.columns(2)

                    with col1:
                        st.markdown(f"**User ID:** {doc.user_id}")
                        st.markdown(f"**Type:** {doc.file_type.upper()}")
                        st.markdown(f"**Size:** {doc.file_size / 1024:.1f} KB")

                    with col2:
                        st.markdown(f"**Chunks:** {doc.num_chunks}")
                        st.markdown(f"**Collection:** {doc.collection_name}")
                        st.markdown(f"**Uploaded:** {doc.upload_date.strftime('%Y-%m-%d %H:%M')}")

        finally:
            db_session.close()

    # Tab 4: Settings
    with tabs[3]:
        st.subheader("System Settings")
        st.markdown("Configure LLM and embedding model settings")

        from utils.env_manager import EnvManager

        # Read current settings
        current_env = EnvManager.read_env_file()

        with st.form("settings_form"):
            st.markdown("### LLM Provider Configuration")

            # Provider Selection
            llm_provider = st.selectbox(
                "LLM Provider",
                options=["openai", "ollama"],
                index=0 if current_env.get('LLM_PROVIDER', 'openai') == 'openai' else 1,
                help="Select the LLM provider (OpenAI-compatible API or Ollama)"
            )

            st.markdown("---")

            if llm_provider == "openai":
                st.markdown("### OpenAI Configuration")

                col1, col2 = st.columns(2)

                with col1:
                    llm_base_url = st.text_input(
                        "LLM Base URL",
                        value=current_env.get('LLM_BASE_URL', 'https://xxx.xxx.in'),
                        help="Base URL for LLM API endpoint"
                    )

                    llm_model = st.text_input(
                        "LLM Model",
                        value=current_env.get('LLM_MODEL', 'azure_ai/genailab-maas-DeepSeek-V3-0324'),
                        help="Model identifier for LLM"
                    )

                with col2:
                    llm_api_key = st.text_input(
                        "LLM API Key",
                        value=current_env.get('LLM_API_KEY', ''),
                        type="password",
                        help="API key for LLM access"
                    )

                    max_tokens = st.number_input(
                        "Max Tokens",
                        value=int(current_env.get('MAX_TOKENS', 4000)),
                        min_value=100,
                        max_value=100000,
                        step=100,
                        help="Maximum tokens per response"
                    )

                st.markdown("---")
                st.markdown("### Embedding Configuration")

                col1, col2 = st.columns(2)

                with col1:
                    embedding_base_url = st.text_input(
                        "Embedding Base URL",
                        value=current_env.get('EMBEDDING_BASE_URL', 'https://xxx.xxx.in'),
                        help="Base URL for embedding API endpoint"
                    )

                    embedding_model = st.text_input(
                        "Embedding Model",
                        value=current_env.get('EMBEDDING_MODEL', 'azure/genailab-maas-text-embedding-3-large'),
                        help="Model identifier for embeddings"
                    )

                with col2:
                    embedding_api_key = st.text_input(
                        "Embedding API Key",
                        value=current_env.get('EMBEDDING_API_KEY', ''),
                        type="password",
                        help="API key for embedding access"
                    )

                    temperature = st.slider(
                        "Temperature",
                        min_value=0.0,
                        max_value=2.0,
                        value=float(current_env.get('TEMPERATURE', 0.7)),
                        step=0.1,
                        help="Controls randomness in responses (0=deterministic, 2=very random)"
                    )

                # Set Ollama fields to defaults for update dictionary
                ollama_base_url = "http://localhost:11434"
                ollama_llm_model = "llama3.2"
                ollama_embedding_model = "nomic-embed-text"
                # Embedding tunables
                embedding_batch_size = int(current_env.get('EMBEDDING_BATCH_SIZE', 16))
                embedding_retry_attempts = int(current_env.get('EMBEDDING_RETRY_ATTEMPTS', 5))
                embedding_retry_delay_sec = float(current_env.get('EMBEDDING_RETRY_DELAY_SEC', 0.75))
                embedding_batch_delay_ms = int(current_env.get('EMBEDDING_BATCH_DELAY_MS', 75))

            else:  # ollama
                st.markdown("### Ollama Configuration")

                # Check Ollama connection status
                ollama_check_url = current_env.get('OLLAMA_BASE_URL', 'http://localhost:11434')
                is_connected, status_msg = check_ollama_connection(ollama_check_url)

                if is_connected:
                    st.success(f"Ollama Status: {status_msg}")

                    # Show available models
                    success, models = list_ollama_models(ollama_check_url)
                    if success and models:
                        with st.expander("Installed Models", expanded=False):
                            for model in models:
                                model_name = model.get('name', 'Unknown')
                                model_size = model.get('size', 0)
                                st.markdown(f"- **{model_name}** ({format_model_size(model_size)})")
                else:
                    st.error(f"Ollama Status: {status_msg}")
                    st.info("Start Ollama with: `ollama serve`")

                col1, col2 = st.columns(2)

                with col1:
                    ollama_base_url = st.text_input(
                        "Ollama Base URL",
                        value=current_env.get('OLLAMA_BASE_URL', 'http://localhost:11434'),
                        help="Base URL for local Ollama instance"
                    )

                    ollama_llm_model = st.text_input(
                        "Ollama LLM Model",
                        value=current_env.get('OLLAMA_LLM_MODEL', 'llama3.2'),
                        help="Ollama model for LLM (e.g., llama3.2, mistral, codellama)"
                    )

                with col2:
                    ollama_embedding_model = st.text_input(
                        "Ollama Embedding Model",
                        value=current_env.get('OLLAMA_EMBEDDING_MODEL', 'nomic-embed-text'),
                        help="Ollama model for embeddings (e.g., nomic-embed-text, mxbai-embed-large)"
                    )

                    max_tokens = st.number_input(
                        "Max Tokens",
                        value=int(current_env.get('MAX_TOKENS', 4000)),
                        min_value=100,
                        max_value=100000,
                        step=100,
                        help="Maximum tokens per response"
                    )

                temperature = st.slider(
                    "Temperature",
                    min_value=0.0,
                    max_value=2.0,
                    value=float(current_env.get('TEMPERATURE', 0.7)),
                    step=0.1,
                    help="Controls randomness in responses (0=deterministic, 2=very random)"
                )

                # Show recommended models
                st.markdown("---")
                st.markdown("### Embedding Performance Settings")
                col1, col2 = st.columns(2)
                with col1:
                    embedding_batch_size = st.number_input(
                        "Batch Size",
                        min_value=1,
                        max_value=128,
                        value=int(current_env.get('EMBEDDING_BATCH_SIZE', 16)),
                        help="Number of chunks per embedding batch"
                    )
                    embedding_retry_attempts = st.number_input(
                        "Retry Attempts",
                        min_value=1,
                        max_value=10,
                        value=int(current_env.get('EMBEDDING_RETRY_ATTEMPTS', 5)),
                        help="Number of retries on transient errors"
                    )
                with col2:
                    embedding_retry_delay_sec = st.number_input(
                        "Retry Delay (sec)",
                        min_value=0.1,
                        max_value=5.0,
                        value=float(current_env.get('EMBEDDING_RETRY_DELAY_SEC', 0.75)),
                        step=0.05,
                        help="Delay between retries"
                    )
                    embedding_batch_delay_ms = st.number_input(
                        "Batch Delay (ms)",
                        min_value=0,
                        max_value=1000,
                        value=int(current_env.get('EMBEDDING_BATCH_DELAY_MS', 75)),
                        help="Delay between batches"
                    )

                # Set OpenAI fields to empty for update dictionary
                llm_base_url = ""
                llm_model = ""
                llm_api_key = ""
                embedding_base_url = ""
                embedding_model = ""
                embedding_api_key = ""

                st.info("Note: Make sure Ollama is running locally and the specified models are downloaded. Run `ollama pull <model-name>` to download models.")

            st.markdown("---")

            col1, col2 = st.columns([1, 1])

            with col1:
                submitted = st.form_submit_button("Save Settings", use_container_width=True, type="primary")

            with col2:
                if st.form_submit_button("Reset to Current", use_container_width=True):
                    st.rerun()

            st.warning("Changing these settings will update the .env file. You may need to restart the application for changes to take full effect.")

        if submitted:
            # Validate provider connectivity if needed
            if llm_provider == "ollama":
                ok, msg = check_ollama_connection(ollama_base_url)
                if not ok:
                    st.error(f"Cannot connect to Ollama at '{ollama_base_url}': {msg}")
                    st.stop()

            # Prepare updates
            updates = {
                'LLM_PROVIDER': llm_provider,
                'MAX_TOKENS': str(max_tokens),
                'TEMPERATURE': str(temperature)
            }

            # Add provider-specific settings
            if llm_provider == "openai":
                updates.update({
                    'LLM_BASE_URL': llm_base_url,
                    'LLM_MODEL': llm_model,
                    'LLM_API_KEY': llm_api_key,
                    'EMBEDDING_BASE_URL': embedding_base_url,
                    'EMBEDDING_MODEL': embedding_model,
                    'EMBEDDING_API_KEY': embedding_api_key
                })
            else:  # ollama
                updates.update({
                    'OLLAMA_BASE_URL': ollama_base_url,
                    'OLLAMA_LLM_MODEL': ollama_llm_model,
                    'OLLAMA_EMBEDDING_MODEL': ollama_embedding_model,
                    'EMBEDDING_BATCH_SIZE': str(embedding_batch_size),
                    'EMBEDDING_RETRY_ATTEMPTS': str(embedding_retry_attempts),
                    'EMBEDDING_RETRY_DELAY_SEC': str(embedding_retry_delay_sec),
                    'EMBEDDING_BATCH_DELAY_MS': str(embedding_batch_delay_ms)
                })

            # Update .env file
            success = EnvManager.update_env_file(updates)

            if success:
                st.success("Settings saved successfully to .env file!")
                if llm_provider == "ollama":
                    st.info("Ollama Setup: Ensure Ollama is running with `ollama serve` and models are downloaded with `ollama pull <model-name>`")
                else:
                    st.info("Note: Some changes may require restarting the application to take effect.")

                # Log the update
                from utils.logger import log_info
                log_info("Admin updated system settings")
            else:
                st.error("Failed to save settings. Please check file permissions.")

        # Display current configuration
        st.markdown("---")
        st.markdown("### Current Configuration")

        col1, col2 = st.columns(2)

        with col1:
            st.code(f"""
LLM Settings:
• Base URL: {current_env.get('LLM_BASE_URL', 'Not set')}
• Model: {current_env.get('LLM_MODEL', 'Not set')}
• API Key: {'*' * 20 if current_env.get('LLM_API_KEY') else 'Not set'}
• Max Tokens: {current_env.get('MAX_TOKENS', 'Not set')}
• Temperature: {current_env.get('TEMPERATURE', 'Not set')}
            """)

        with col2:
            st.code(f"""
Embedding Settings:
• Base URL: {current_env.get('EMBEDDING_BASE_URL', 'Not set')}
• Model: {current_env.get('EMBEDDING_MODEL', 'Not set')}
• API Key: {'*' * 20 if current_env.get('EMBEDDING_API_KEY') else 'Not set'}
            """)

    # Tab 5: System Actions
    with tabs[4]:

        col1, col2 = st.columns(2)

        with col1:
            st.markdown("### Cache Management")

            if st.button("Clear Expired Cache", use_container_width=True):
                from services.cache_service import CacheService
                deleted = CacheService.clear_expired()
                st.success(f"Cleared {deleted} expired cache entries")

            if st.button("Clear All Cache", use_container_width=True, type="secondary"):
                from services.cache_service import CacheService
                deleted = CacheService.clear_all()
                st.warning(f"Cleared all {deleted} cache entries")

        with col2:
            st.markdown("### Database Actions")

            if st.button("Initialize Database", use_container_width=True):
                from models import init_db
                init_db()
                st.success("Database initialized")

        st.warning("These actions can affect system performance and data. Use with caution.")

        st.markdown("### System Information")
        from config.settings import settings
        st.info(f"""
        **App Name:** {settings.app_name}
        **Version:** {settings.app_version}
        **LLM Model:** {settings.llm_model}
        **Embedding Model:** {settings.embedding_model}
        """)


if __name__ == "__main__":
    show()
