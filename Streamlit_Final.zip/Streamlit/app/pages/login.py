"""
Login Page
"""

import streamlit as st
from utils.auth import AuthService
from utils.session import login_user
from utils.logger import log_info


def show():
    """Display login page"""

    st.title("Login")
    st.markdown("Welcome back! Please log in to continue.")

    with st.form("login_form"):
        username = st.text_input("Username or Email", placeholder="Enter your username or email")
        password = st.text_input("Password", type="password", placeholder="Enter your password")

        col1, col2 = st.columns([1, 1])

        with col1:
            submit = st.form_submit_button("Login", use_container_width=True)

        with col2:
            if st.form_submit_button("Create Account", use_container_width=True):
                from utils.session import navigate_to
                navigate_to("register")
                st.rerun()

    if submit:
        if not username or not password:
            st.error("Please enter both username and password")
        else:
            # Authenticate user (returns dict or None)
            user_dict = AuthService.authenticate_user(username, password)

            if user_dict:
                # Create token
                token = AuthService.create_access_token(
                    user_dict['id'],
                    user_dict['username'],
                    user_dict['is_admin']
                )

                # Login user
                login_user(user_dict, token)
                log_info(f"User {user_dict['username']} logged in")
                st.success("Login successful!")
                st.rerun()
                st.rerun()
            else:
                st.error("Invalid username or password")

    # Info section
    st.markdown("---")
    st.info("""
    **First time here?**

    Click "Create Account" to register a new account.

    **Features:**
    - AI-powered Q&A with RAG
    - Document search and analysis
    - Multi-agent system
    - Explainable AI insights
    """)


if __name__ == "__main__":
    show()
