"""
Registration Page
"""

import streamlit as st
from utils.auth import AuthService, ROLES
from utils.session import get_current_user, is_authenticated
from utils.validators import validate_username, validate_email, validate_password, validate_full_name
from utils.logger import log_info


def show():
    """Display registration page"""

    st.title("Create Account")
    st.markdown("Join us and start using AI-powered features!")

    with st.form("registration_form"):
        username = st.text_input("Username*", placeholder="Choose a unique username")
        email = st.text_input("Email*", placeholder="your.email@example.com")
        full_name = st.text_input("Full Name (optional)", placeholder="John Doe")
        password = st.text_input("Password*", type="password", placeholder="Create a strong password")
        password_confirm = st.text_input("Confirm Password*", type="password", placeholder="Re-enter your password")

        # Role selection only visible to currently authenticated admins creating other accounts
        selected_role = 'user'
        if is_authenticated():
            current = get_current_user()
            if current and (current.get('role') == 'admin'):
                selected_role = st.selectbox(
                    "Assign Role",
                    options=sorted(list(ROLES)),
                    index=sorted(list(ROLES)).index('user'),
                    help="Role for the new user (only admins can assign)"
                )

        st.markdown("""
        **Password requirements:**
        - At least 8 characters
        - One uppercase letter
        - One lowercase letter
        - One number
        """)

        col1, col2 = st.columns([1, 1])

        with col1:
            submit = st.form_submit_button("Register", use_container_width=True)

        with col2:
            if st.form_submit_button("Back to Login", use_container_width=True):
                from utils.session import navigate_to
                navigate_to("login")
                st.rerun()

    if submit:
        # Validation
        errors = []

        is_valid, msg = validate_username(username)
        if not is_valid:
            errors.append(msg)

        is_valid, msg = validate_email(email)
        if not is_valid:
            errors.append(msg)

        is_valid, msg = validate_password(password)
        if not is_valid:
            errors.append(msg)

        if full_name:
            is_valid, msg = validate_full_name(full_name)
            if not is_valid:
                errors.append(msg)

        if password != password_confirm:
            errors.append("Passwords do not match")

        if errors:
            for error in errors:
                st.error(error)
        else:
            # Register user
            success, message, user = AuthService.register_user(
                username=username,
                email=email,
                password=password,
                full_name=full_name if full_name else None,
                role=selected_role
            )

            if success:
                st.success(message)
                log_info(f"New user registered: {username}")
                st.info("Please log in with your new account")

                from utils.session import navigate_to
                navigate_to("login")
                st.rerun()
            else:
                st.error(message)


if __name__ == "__main__":
    show()
