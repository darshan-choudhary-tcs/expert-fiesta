"""
RAG Uploader Page
"""

import streamlit as st
from utils.session import require_auth, get_current_user_id
from services.document_processor import DocumentProcessor
from services.vector_store import VectorStoreService
from models.document import UserDocument
from models.user import get_session
from utils.validators import validate_file_upload
from utils.logger import log_info, log_error
from config.settings import settings


@require_auth
def show():
    """Display RAG Uploader page"""

    st.title("RAG Uploader")
    st.markdown("Upload and manage your documents for AI-powered search")

    user_id = get_current_user_id()

    # Upload section
    st.subheader("Upload Documents")

    col1, col2 = st.columns([2, 1])

    with col1:
        uploaded_file = st.file_uploader(
            "Choose a file",
            type=['pdf', 'txt', 'docx'],
            help=f"Supported formats: PDF, TXT, DOCX (Max {settings.max_upload_size_mb}MB)"
        )

    with col2:
        collection_name = st.text_input(
            "Collection Name",
            value=f"user_{user_id}",
            help="Name for organizing documents"
        )

    if uploaded_file is not None:
        # Validate file
        is_valid, msg = validate_file_upload(
            uploaded_file.name,
            uploaded_file.size,
            settings.max_upload_size_mb
        )

        if not is_valid:
            st.error(msg)
        else:
            if st.button("Process and Upload", use_container_width=True):
                with st.spinner("Processing document..."):
                    try:
                        # Extract text
                        file_content = uploaded_file.read()
                        success, text, error = DocumentProcessor.extract_text(
                            uploaded_file.name,
                            file_content
                        )

                        if not success:
                            st.error(f"Failed to extract text: {error}")
                            return

                        # Show preview
                        st.success(f"Extracted {len(text)} characters")

                        with st.expander("Preview extracted text"):
                            st.text(text[:500] + "..." if len(text) > 500 else text)

                        # Chunk text
                        chunks = DocumentProcessor.chunk_text(text)
                        st.info(f"Created {len(chunks)} chunks")

                        # Create metadata
                        metadatas = [
                            DocumentProcessor.create_metadata(
                                uploaded_file.name,
                                i,
                                len(chunks),
                                user_id
                            )
                            for i in range(len(chunks))
                        ]

                        # Add to vector store
                        vector_store = VectorStoreService(collection_name)
                        doc_ids = vector_store.add_documents(chunks, metadatas)

                        # Save document record
                        db_session = get_session()
                        try:
                            doc_record = UserDocument(
                                user_id=user_id,
                                filename=uploaded_file.name,
                                original_filename=uploaded_file.name,
                                file_type=uploaded_file.name.split('.')[-1],
                                file_size=uploaded_file.size,
                                collection_name=collection_name,
                                num_chunks=len(chunks)
                            )
                            db_session.add(doc_record)
                            db_session.commit()
                        finally:
                            db_session.close()

                        st.success(f"Successfully uploaded: {uploaded_file.name}")
                        # Persist selected collection to session for Dashboard sync
                        st.session_state['current_collection'] = collection_name
                        log_info(f"User {user_id} uploaded document: {uploaded_file.name}")

                    except Exception as e:
                        st.error(f"Error processing document: {str(e)}")
                        log_error(f"Document upload error: {e}", exc_info=True)

    # Document list
    st.markdown("---")
    st.subheader("Your Documents")

    # Fetch user documents
    db_session = get_session()
    try:
        docs = db_session.query(UserDocument).filter(
            UserDocument.user_id == user_id
        ).order_by(UserDocument.upload_date.desc()).all()

        if not docs:
            st.info("No documents uploaded yet. Upload your first document above!")
        else:
            for doc in docs:
                with st.expander(f"{doc.filename} - {doc.file_type.upper()}"):
                    col1, col2 = st.columns([3, 1])

                    with col1:
                        st.markdown(f"**Size:** {doc.file_size / 1024:.1f} KB")
                        st.markdown(f"**Chunks:** {doc.num_chunks}")
                        st.markdown(f"**Collection:** {doc.collection_name}")
                        st.markdown(f"**Uploaded:** {doc.upload_date.strftime('%Y-%m-%d %H:%M')}")

                    with col2:
                        if st.button(f"Delete", key=f"del_{doc.id}"):
                            # Delete from database
                            db_session.delete(doc)
                            db_session.commit()
                            st.success("Document deleted")
                            st.rerun()

    finally:
        db_session.close()

    # Collections info
    st.markdown("---")
    st.subheader("Existing Collections")

    collections = VectorStoreService.list_collections()

    if collections:
        for coll in collections:
            vector_store = VectorStoreService(coll)
            count = vector_store.get_collection_count()
            st.markdown(f"- **{coll}**: {count} chunks")
    else:
        st.info("No collections found")


if __name__ == "__main__":
    show()
