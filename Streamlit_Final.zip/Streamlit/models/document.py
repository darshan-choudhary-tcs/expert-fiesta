"""
Database Models - Document Management
Defines UserDocument model for uploaded documents
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey, Float
from sqlalchemy.orm import relationship
from models.user import Base


class UserDocument(Base):
    """User document model for storing uploaded file metadata"""
    __tablename__ = 'user_documents'

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False, index=True)
    filename = Column(String(255), nullable=False)
    original_filename = Column(String(255), nullable=False)
    file_type = Column(String(50), nullable=False)  # 'pdf', 'txt', 'docx'
    file_size = Column(Integer)  # Size in bytes
    collection_name = Column(String(100), nullable=False, index=True)  # ChromaDB collection
    num_chunks = Column(Integer, default=0)
    upload_date = Column(DateTime, default=datetime.utcnow, index=True)
    description = Column(Text)
    meta_data = Column(Text)  # JSON string for additional metadata

    # Relationships
    user = relationship("User", back_populates="documents")

    def __repr__(self):
        return f"<UserDocument(filename='{self.filename}', user_id={self.user_id})>"

    def to_dict(self):
        """Convert document to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'filename': self.filename,
            'original_filename': self.original_filename,
            'file_type': self.file_type,
            'file_size': self.file_size,
            'collection_name': self.collection_name,
            'num_chunks': self.num_chunks,
            'upload_date': self.upload_date.isoformat() if self.upload_date else None,
            'description': self.description
        }
