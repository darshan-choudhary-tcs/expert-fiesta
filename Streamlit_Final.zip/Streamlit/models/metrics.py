"""
Database Models - Performance Metrics
Tracks system performance and usage statistics
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Float, Text, Boolean
from models.user import Base


class PerformanceMetric(Base):
    """Performance metrics model for monitoring system performance"""
    __tablename__ = 'performance_metrics'

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, index=True)
    session_id = Column(String(100), index=True)
    metric_type = Column(String(50), nullable=False, index=True)  # 'query', 'embedding', 'agent'
    operation = Column(String(100))  # Specific operation name

    # Performance metrics
    latency_ms = Column(Float)  # Total latency in milliseconds
    tokens_used = Column(Integer)
    tokens_prompt = Column(Integer)
    tokens_completion = Column(Integer)

    # RAG metrics
    num_documents_retrieved = Column(Integer)
    avg_relevance_score = Column(Float)
    cache_hit = Column(Boolean, default=False)

    # Agent metrics
    agent_name = Column(String(100))
    num_agent_steps = Column(Integer)
    agent_success = Column(Boolean)

    # Additional data
    error_message = Column(Text)
    meta_data = Column(Text)  # JSON string for additional metrics
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)

    def __repr__(self):
        return f"<PerformanceMetric(type='{self.metric_type}', latency={self.latency_ms}ms)>"

    def to_dict(self):
        """Convert metric to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'session_id': self.session_id,
            'metric_type': self.metric_type,
            'operation': self.operation,
            'latency_ms': self.latency_ms,
            'tokens_used': self.tokens_used,
            'tokens_prompt': self.tokens_prompt,
            'tokens_completion': self.tokens_completion,
            'num_documents_retrieved': self.num_documents_retrieved,
            'avg_relevance_score': self.avg_relevance_score,
            'cache_hit': self.cache_hit,
            'agent_name': self.agent_name,
            'num_agent_steps': self.num_agent_steps,
            'agent_success': self.agent_success,
            'error_message': self.error_message,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }


class SystemStats(Base):
    """System statistics model for aggregated metrics"""
    __tablename__ = 'system_stats'

    id = Column(Integer, primary_key=True, autoincrement=True)
    stat_date = Column(DateTime, nullable=False, index=True)
    total_queries = Column(Integer, default=0)
    total_users = Column(Integer, default=0)
    total_documents = Column(Integer, default=0)
    avg_latency_ms = Column(Float)
    total_tokens_used = Column(Integer, default=0)
    cache_hit_rate = Column(Float)
    error_rate = Column(Float)

    def __repr__(self):
        return f"<SystemStats(date='{self.stat_date}', queries={self.total_queries})>"

    def to_dict(self):
        """Convert stats to dictionary"""
        return {
            'id': self.id,
            'stat_date': self.stat_date.isoformat() if self.stat_date else None,
            'total_queries': self.total_queries,
            'total_users': self.total_users,
            'total_documents': self.total_documents,
            'avg_latency_ms': self.avg_latency_ms,
            'total_tokens_used': self.total_tokens_used,
            'cache_hit_rate': self.cache_hit_rate,
            'error_rate': self.error_rate
        }
