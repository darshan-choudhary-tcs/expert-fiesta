"""
Database Models - User Management
Defines User, ConversationHistory, and related models
"""

from datetime import datetime
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey, Float
from sqlalchemy import inspect
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from config.settings import settings

Base = declarative_base()


class User(Base):
    """User model for authentication and profile management"""
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50), unique=True, nullable=False, index=True)
    email = Column(String(100), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(100))
    is_active = Column(Boolean, default=True)
    # Legacy admin flag retained for backward compatibility; prefer role column going forward
    is_admin = Column(Boolean, default=False)
    role = Column(String(20), default='user', index=True)  # 'admin' | 'editor' | 'user'
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime)

    # Relationships
    conversations = relationship("ConversationHistory", back_populates="user", cascade="all, delete-orphan")
    documents = relationship("UserDocument", back_populates="user", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<User(username='{self.username}', email='{self.email}')>"

    def to_dict(self):
        """Convert user to dictionary (exclude password)"""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'is_active': self.is_active,
            'is_admin': self.is_admin or self.role == 'admin',  # derived for compatibility
            'role': self.role,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }


class ConversationHistory(Base):
    """Conversation history model for storing chat sessions"""
    __tablename__ = 'conversation_history'

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False, index=True)
    session_id = Column(String(100), nullable=False, index=True)
    message_type = Column(String(20), nullable=False)  # 'user', 'assistant', 'system'
    message_content = Column(Text, nullable=False)
    meta_data = Column(Text)  # JSON string for additional data
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)

    # Relationships
    user = relationship("User", back_populates="conversations")

    def __repr__(self):
        return f"<ConversationHistory(user_id={self.user_id}, type='{self.message_type}')>"

    def to_dict(self):
        """Convert conversation to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'session_id': self.session_id,
            'message_type': self.message_type,
            'message_content': self.message_content,
            'metadata': self.meta_data,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None
        }


# Database initialization
def get_engine():
    """Create SQLAlchemy engine"""
    db_path = settings.get_db_path()
    engine = create_engine(f'sqlite:///{db_path}', echo=False)
    return engine


def get_session():
    """Get database session"""
    engine = get_engine()
    Session = sessionmaker(bind=engine)
    return Session()


def init_db():
    """Initialize database - create all tables"""
    engine = get_engine()
    Base.metadata.create_all(engine)
    _upgrade_schema(engine)
    # print(f"Database initialized at {settings.get_db_path()}")


def drop_all_tables():
    """Drop all tables (use with caution!)"""
    engine = get_engine()
    Base.metadata.drop_all(engine)
    print("All tables dropped")


def _upgrade_schema(engine):
    """Perform lightweight in-place schema upgrades (idempotent)."""
    try:
        inspector = inspect(engine)
        columns = [col['name'] for col in inspector.get_columns('users')]
        with engine.connect() as conn:
            # Add role column if missing
            if 'role' not in columns:
                conn.execute("ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'user'")
            # Backfill null roles (older rows)
            conn.execute("UPDATE users SET role='admin' WHERE is_admin=1 AND (role IS NULL OR role='')")
            conn.execute("UPDATE users SET role='user' WHERE (role IS NULL OR role='')")
    except Exception as e:
        print(f"Schema upgrade warning: {e}")


if __name__ == "__main__":
    # Initialize database when module is run directly
    init_db()
