"""
Models Package Initializer
Imports all models and provides database initialization
"""

from models.user import Base, User, ConversationHistory, get_engine, get_session, init_db
from models.document import UserDocument
from models.metrics import PerformanceMetric, SystemStats

__all__ = [
    'Base',
    'User',
    'ConversationHistory',
    'UserDocument',
    'PerformanceMetric',
    'SystemStats',
    'get_engine',
    'get_session',
    'init_db'
]


def initialize_all_models():
    """Initialize all database models"""
    init_db()
    print("All models initialized successfully")


if __name__ == "__main__":
    initialize_all_models()
