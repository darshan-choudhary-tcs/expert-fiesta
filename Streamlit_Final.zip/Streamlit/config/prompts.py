"""
Configuration Package - Prompt Templates
Additional helper prompts
"""

# System messages for different contexts
SYSTEM_MESSAGES = {
    'helpful': "You are a helpful AI assistant. Provide clear, accurate, and concise answers.",
    'analytical': "You are an analytical AI assistant. Focus on data, facts, and logical reasoning.",
    'creative': "You are a creative AI assistant. Think outside the box and provide innovative solutions.",
    'technical': "You are a technical AI assistant with expertise in software and technology."
}

# Few-shot examples for RAG
RAG_FEW_SHOT_EXAMPLES = [
    {
        'context': "The capital of France is Paris. Paris is known for the Eiffel Tower.",
        'question': "What is the capital of France?",
        'answer': "The capital of France is Paris. [Source: Document 1]"
    },
    {
        'context': "Python is a high-level programming language. It was created by Guido van Rossum.",
        'question': "Who created Python?",
        'answer': "Python was created by Guido van Rossum. [Source: Document 1]"
    }
]

# Error messages
ERROR_MESSAGES = {
    'no_documents': "I couldn't find any relevant documents to answer your question. Please try rephrasing or upload relevant documents.",
    'api_error': "I encountered an error while processing your request. Please try again.",
    'auth_error': "Authentication failed. Please log in again.",
    'permission_error': "You don't have permission to perform this action."
}

# Success messages
SUCCESS_MESSAGES = {
    'document_uploaded': "Document uploaded successfully!",
    'profile_updated': "Profile updated successfully!",
    'password_changed': "Password changed successfully!"
}
