"""
Configuration Settings Module
Loads and validates environment variables for the application
"""

import os
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings

# Load environment variables
load_dotenv()

# Base directory
BASE_DIR = Path(__file__).parent.parent


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""

    # Provider Selection
    llm_provider: str = Field(default="openai", env="LLM_PROVIDER")  # "openai" or "ollama"

    # LLM Configuration
    llm_base_url: str = Field(default="https://xxx.xxx.in", env="LLM_BASE_URL")
    llm_model: str = Field(default="azure_ai/genailab-maas-DeepSeek-V3-0324", env="LLM_MODEL")
    llm_api_key: str = Field(default="", env="LLM_API_KEY")

    # Ollama Configuration
    ollama_base_url: str = Field(default="http://localhost:11434", env="OLLAMA_BASE_URL")
    ollama_llm_model: str = Field(default="llama3.2", env="OLLAMA_LLM_MODEL")
    ollama_embedding_model: str = Field(default="nomic-embed-text", env="OLLAMA_EMBEDDING_MODEL")

    # Embedding Configuration
    embedding_base_url: str = Field(default="https://xxx.xxx.in", env="EMBEDDING_BASE_URL")
    embedding_model: str = Field(default="azure/genailab-maas-text-embedding-3-large", env="EMBEDDING_MODEL")
    embedding_api_key: str = Field(default="", env="EMBEDDING_API_KEY")

    # Database Paths
    sqlite_db_path: str = Field(default="./data/app.db", env="SQLITE_DB_PATH")
    chroma_db_path: str = Field(default="./data/chroma_db", env="CHROMA_DB_PATH")

    # Authentication
    jwt_secret_key: str = Field(default="change_this_secret_key_in_production", env="JWT_SECRET_KEY")
    jwt_algorithm: str = Field(default="HS256", env="JWT_ALGORITHM")
    jwt_expiration_hours: int = Field(default=24, env="JWT_EXPIRATION_HOURS")

    # Application Settings
    app_name: str = Field(default="GenAI Hackathon Platform", env="APP_NAME")
    app_version: str = Field(default="1.0.0", env="APP_VERSION")
    max_upload_size_mb: int = Field(default=10, env="MAX_UPLOAD_SIZE_MB")
    chunk_size: int = Field(default=1000, env="CHUNK_SIZE")
    chunk_overlap: int = Field(default=200, env="CHUNK_OVERLAP")
    # Embedding tunables
    embedding_batch_size: int = Field(default=16, env="EMBEDDING_BATCH_SIZE")
    embedding_retry_attempts: int = Field(default=5, env="EMBEDDING_RETRY_ATTEMPTS")
    embedding_retry_delay_sec: float = Field(default=0.75, env="EMBEDDING_RETRY_DELAY_SEC")
    embedding_batch_delay_ms: int = Field(default=75, env="EMBEDDING_BATCH_DELAY_MS")

    # Performance Settings
    cache_enabled: bool = Field(default=True, env="CACHE_ENABLED")
    cache_ttl_seconds: int = Field(default=3600, env="CACHE_TTL_SECONDS")
    max_tokens: int = Field(default=4000, env="MAX_TOKENS")
    temperature: float = Field(default=0.7, env="TEMPERATURE")

    # Logging
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    log_file: str = Field(default="./logs/app.log", env="LOG_FILE")

    class Config:
        env_file = ".env"
        case_sensitive = False

    def get_db_path(self) -> Path:
        """Get absolute path for SQLite database"""
        db_path = Path(self.sqlite_db_path)
        if not db_path.is_absolute():
            db_path = BASE_DIR / db_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        return db_path

    def get_chroma_path(self) -> Path:
        """Get absolute path for ChromaDB"""
        chroma_path = Path(self.chroma_db_path)
        if not chroma_path.is_absolute():
            chroma_path = BASE_DIR / chroma_path
        chroma_path.mkdir(parents=True, exist_ok=True)
        return chroma_path

    def get_log_path(self) -> Path:
        """Get absolute path for log file"""
        log_path = Path(self.log_file)
        if not log_path.is_absolute():
            log_path = BASE_DIR / log_path
        log_path.parent.mkdir(parents=True, exist_ok=True)
        return log_path

    def validate_settings(self) -> list[str]:
        """Validate critical settings and return list of warnings"""
        warnings = []

        if not self.llm_api_key or self.llm_api_key == "your_api_key_here":
            warnings.append("LLM_API_KEY not configured")

        if not self.embedding_api_key or self.embedding_api_key == "your_api_key_here":
            warnings.append("EMBEDDING_API_KEY not configured")

        if self.jwt_secret_key == "change_this_secret_key_in_production":
            warnings.append("JWT_SECRET_KEY using default value - change for production")

        return warnings


# Global settings instance
settings = Settings()

# Create necessary directories
settings.get_db_path()
settings.get_chroma_path()
settings.get_log_path()
